--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg22.04+1)
-- Dumped by pg_dump version 15.1 (Ubuntu 15.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE quizapp;
--
-- Name: quizapp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE quizapp WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE quizapp OWNER TO postgres;

\connect quizapp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: crud; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA crud;


ALTER SCHEMA crud OWNER TO postgres;

--
-- Name: helper; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA helper;


ALTER SCHEMA helper OWNER TO postgres;

--
-- Name: logs; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA logs;


ALTER SCHEMA logs OWNER TO postgres;

--
-- Name: mapper; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA mapper;


ALTER SCHEMA mapper OWNER TO postgres;

--
-- Name: quizapp; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA quizapp;


ALTER SCHEMA quizapp OWNER TO postgres;

--
-- Name: utils; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA utils;


ALTER SCHEMA utils OWNER TO postgres;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA utils;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: answer_dto; Type: TYPE; Schema: quizapp; Owner: postgres
--

CREATE TYPE quizapp.answer_dto AS (
	question_id integer,
	choices jsonb
);


ALTER TYPE quizapp.answer_dto OWNER TO postgres;

--
-- Name: level_create_dto; Type: TYPE; Schema: quizapp; Owner: postgres
--

CREATE TYPE quizapp.level_create_dto AS (
	code character varying,
	subject character varying,
	translations jsonb
);


ALTER TYPE quizapp.level_create_dto OWNER TO postgres;

--
-- Name: question_create_dto; Type: TYPE; Schema: quizapp; Owner: postgres
--

CREATE TYPE quizapp.question_create_dto AS (
	title character varying,
	subject character varying,
	level character varying,
	language character varying,
	choices jsonb,
	translations jsonb
);


ALTER TYPE quizapp.question_create_dto OWNER TO postgres;

--
-- Name: quiz_generate_dto; Type: TYPE; Schema: quizapp; Owner: postgres
--

CREATE TYPE quizapp.quiz_generate_dto AS (
	language character varying,
	subject character varying,
	level character varying,
	questioncount integer
);


ALTER TYPE quizapp.quiz_generate_dto OWNER TO postgres;

--
-- Name: subject_create_dto; Type: TYPE; Schema: quizapp; Owner: postgres
--

CREATE TYPE quizapp.subject_create_dto AS (
	code character varying,
	name character varying,
	translations jsonb
);


ALTER TYPE quizapp.subject_create_dto OWNER TO postgres;

--
-- Name: user_register_dto; Type: TYPE; Schema: quizapp; Owner: postgres
--

CREATE TYPE quizapp.user_register_dto AS (
	username character varying,
	password character varying,
	language character varying,
	role character varying
);


ALTER TYPE quizapp.user_register_dto OWNER TO postgres;

--
-- Name: category_create_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.category_create_dto AS (
	category_name character varying,
	language_id smallint
);


ALTER TYPE utils.category_create_dto OWNER TO postgres;

--
-- Name: category_update_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.category_update_dto AS (
	category_name character varying,
	category_id smallint
);


ALTER TYPE utils.category_update_dto OWNER TO postgres;

--
-- Name: no_null_length_zero_varchar; Type: DOMAIN; Schema: utils; Owner: postgres
--

CREATE DOMAIN utils.no_null_length_zero_varchar AS character varying NOT NULL
	CONSTRAINT no_null_length_zero_varchar_check CHECK ((length(TRIM(BOTH FROM VALUE)) > 0));


ALTER DOMAIN utils.no_null_length_zero_varchar OWNER TO postgres;

--
-- Name: create_language_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.create_language_dto AS (
	code utils.no_null_length_zero_varchar,
	name utils.no_null_length_zero_varchar
);


ALTER TYPE utils.create_language_dto OWNER TO postgres;

--
-- Name: create_user_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.create_user_dto AS (
	full_name character varying,
	username character varying,
	password character varying,
	email character varying,
	language_id smallint,
	role character varying
);


ALTER TYPE utils.create_user_dto OWNER TO postgres;

--
-- Name: get_test; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.get_test AS (
	category_id smallint,
	number_of_questions integer,
	level_id smallint
);


ALTER TYPE utils.get_test OWNER TO postgres;

--
-- Name: level_create_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.level_create_dto AS (
	level_name character varying,
	category_id smallint
);


ALTER TYPE utils.level_create_dto OWNER TO postgres;

--
-- Name: level_update_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.level_update_dto AS (
	level_id integer,
	level_name character varying,
	power integer
);


ALTER TYPE utils.level_update_dto OWNER TO postgres;

--
-- Name: no_null_length_zero_text; Type: DOMAIN; Schema: utils; Owner: postgres
--

CREATE DOMAIN utils.no_null_length_zero_text AS text NOT NULL
	CONSTRAINT no_null_length_zero_text_check CHECK ((length(TRIM(BOTH FROM VALUE)) > 0));


ALTER DOMAIN utils.no_null_length_zero_text OWNER TO postgres;

--
-- Name: variant_create; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.variant_create AS (
	question_id smallint,
	variant_body utils.no_null_length_zero_text,
	is_correct boolean,
	created_by bigint
);


ALTER TYPE utils.variant_create OWNER TO postgres;

--
-- Name: question_create; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.question_create AS (
	category_id smallint,
	question_body utils.no_null_length_zero_text,
	level_id integer,
	variants utils.variant_create[]
);


ALTER TYPE utils.question_create OWNER TO postgres;

--
-- Name: question_create_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.question_create_dto AS (
	variants utils.variant_create[]
);


ALTER TYPE utils.question_create_dto OWNER TO postgres;

--
-- Name: question_update_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.question_update_dto AS (
	question_body text,
	level_id integer,
	question_id bigint
);


ALTER TYPE utils.question_update_dto OWNER TO postgres;

--
-- Name: quiz_create_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.quiz_create_dto AS (
	user_answers jsonb,
	question_id bigint
);


ALTER TYPE utils.quiz_create_dto OWNER TO postgres;

--
-- Name: submit_answer; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.submit_answer AS (
	quizid integer,
	questionid integer,
	choices bigint[]
);


ALTER TYPE utils.submit_answer OWNER TO postgres;

--
-- Name: update_language_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.update_language_dto AS (
	id bigint,
	name character varying,
	code character varying
);


ALTER TYPE utils.update_language_dto OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.user_role AS ENUM (
    'ADMIN',
    'USER',
    'SUPER_ADMIN',
    'MENTOR'
);


ALTER TYPE utils.user_role OWNER TO postgres;

--
-- Name: update_user_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.update_user_dto AS (
	id bigint,
	full_name character varying,
	username character varying,
	password character varying,
	email character varying,
	language_id smallint,
	role utils.user_role
);


ALTER TYPE utils.update_user_dto OWNER TO postgres;

--
-- Name: variant_update_dto; Type: TYPE; Schema: utils; Owner: postgres
--

CREATE TYPE utils.variant_update_dto AS (
	variant_id bigint,
	variant_body text,
	is_correct boolean
);


ALTER TYPE utils.variant_update_dto OWNER TO postgres;

--
-- Name: categories_get(); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.categories_get() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    result     json;
    r_category record;
BEGIN


    raise warning '%',r_category;

    return (select json_agg(
                           crud.category_get(t.id)
                       )
            from (select * from public.category t where t.is_deleted = 0) as t);

end;
$$;


ALTER FUNCTION crud.categories_get() OWNER TO postgres;

--
-- Name: category_create(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.category_create(dataparam text, i_user_id bigint DEFAULT NULL::bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    dto    utils.category_create_dto;
    newInt bigint;
BEGIN

    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

    dto = mapper.to_category_create_dto(dataparam);

    call helper.check_for_null_or_length_zero(
            dto.category_name::text, 'Category name is invalid');
    call helper.check_for_null_or_length_zero(
            dto.language_id::text, 'Language id is invalid ');

    if helper.hasanyrole('ADMIN#MENTOR', i_user_id) is false then
        raise exception 'Permission denied!';
    end if;
    
    if exists(select *
              from public.category c
              where c.category_name ilike dto.category_name) then
        raise exception 'Category with name ''%'' already exists ', dto.category_name
            using detail = 'Category name should be unique';
    end if;

    if not exists(select * from public.language l where l.is_deleted = 0 and l.id = dto.language_id) then
        raise exception 'Language id not found by ''%'' id', dto.language_id
            using hint = 'Please check language id ';
    end if;

    insert into public.category(category_name, language_id, created_by)
    VALUES (dto.category_name, dto.language_id, i_user_id)
    returning id into newInt;

    return newInt;

END
$$;


ALTER FUNCTION crud.category_create(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: category_delete(smallint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.category_delete(i_category_id smallint, session_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_category record;
BEGIN
    call helper.is_active(session_user_id);
    call helper.check_for_null_or_length_zero(i_category_id::text, 'Category id is invalid');

    if helper.hasanyrole('ADMIN#MENTOR', session_user_id) is false then
        raise exception 'Permission denied!';
    end if;

    select * into r_category from public.category c where c.is_deleted = 0 and c.id = i_category_id;
    if not FOUND then
        raise exception 'Category not found by ''%'' id ', i_category_id;
    end if;

    update public.category c set is_deleted = 1 where c.id = i_category_id;

    return r_category::text;

end;
$$;


ALTER FUNCTION crud.category_delete(i_category_id smallint, session_user_id bigint) OWNER TO postgres;

--
-- Name: category_get(smallint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.category_get(i_category_id smallint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_category record;
BEGIN

    select * into r_category from public.category p where is_deleted = 0 and p.id = i_category_id;

    if not FOUND then
        return null;
    end if;

    return (select json_build_object(
                           'category_name', r_category.category_name,
                           'language_id', r_category.language_id, -- call get_language(language_id);
                           'created_at', r_category.created_at,
                           'created_by', r_category.created_by
                       ));


end;
$$;


ALTER FUNCTION crud.category_get(i_category_id smallint) OWNER TO postgres;

--
-- Name: category_update(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.category_update(dataparam text, i_user_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_category record;
    dto        utils.category_update_dto;

BEGIN
    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

    dto = mapper.to_category_update_dto(dataparam, i_user_id);

    call helper.check_for_null_or_length_zero(dto.category_id::text, 'Category id is invalid');

    call helper.check_admin_or_mentor(i_user_id);

    if dto.category_name is null or length(trim(dto.category_name)) = 0 then
        return dataparam;
    end if;
    
    select * into r_category from public.category c where c.is_deleted = 0 and c.id = dto.category_id;

    if not FOUND then
        raise exception 'Category not found by this ''%'' id ', dto.category_id;
    end if;

    update public.category
    set category_name = dto.category_name,
        updated_by=i_user_id,
        updated_at=now()
    where public.category.id = r_category.id;

    return r_category::text;

END
$$;


ALTER FUNCTION crud.category_update(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: iscorrect(bigint, bigint[]); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.iscorrect(questionid bigint, user_choices bigint[]) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    truevariants bigint[];
begin

    truevariants := array_agg(t.id)
                    from (select t.id from public.variant t where t.is_correct and t.question_id = questionid) t;


    if array_length(truevariants, 1) <> 0 then

        return array_length(truevariants, 1) = array_length(user_choices, 1) AND
               user_choices @> truevariants;

    end if;

    return false;


end
$$;


ALTER FUNCTION crud.iscorrect(questionid bigint, user_choices bigint[]) OWNER TO postgres;

--
-- Name: language_create(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.language_create(data_params text, created_by bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    json_data  json;
    new_id     bigint;
    c_dto      utils.create_language_dto;
    t_language record;
BEGIN
    if data_params is null or data_params = '{}'::text or trim(data_params) = '' then
        raise exception 'Parameters can not be null or empty' using message = 'Check parameters';
    end if;
    json_data := data_params::json;
    c_dto := mapper.json_to_create_language_dto(json_data);
    call helper.check_input_is_null(c_dto.name, 'Language name');
    call helper.check_input_is_null(c_dto.code, 'Language code');
    call helper.is_active(created_by);
    if helper.hasrole(created_by, 'user') then
        raise exception 'Permission denied';
    end if;
    select * into t_language from public.language lan where lan.code ilike c_dto.code;
    if FOUND then
        raise exception 'Language % already exist',t_language.code;
    end if;
    select * into t_language from public.language lan where lan.name ilike c_dto.name;
    if FOUND then
        raise exception 'Language with name % already exist',t_language.name;
    end if;
    insert into public.language(name, code, updated_by, updated_at)
    VALUES (c_dto.name,
            c_dto.code,
            created_by,
            now())
    returning id into new_id;
    return new_id;
END
$$;


ALTER FUNCTION crud.language_create(data_params text, created_by bigint) OWNER TO postgres;

--
-- Name: language_delete(bigint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.language_delete(language_id bigint, session_user_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    t_user     record;
    t_language record;
BEGIN
    call helper.is_active(session_user_id);
    select * into t_user from public.users usr where session_user_id = usr.id;
    if (t_user.role = 'user') is false then
        raise exception 'Permission denied';
    end if;
    select * into t_language from public.language l where l.id = language_id;
    if FOUND then
        update public.language set is_deleted = 1 where id = language_id;
        update public.language set updated_by = session_user_id where id = language_id;
    end if;
    return true;
END
$$;


ALTER FUNCTION crud.language_delete(language_id bigint, session_user_id bigint) OWNER TO postgres;

--
-- Name: language_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.language_get(i_language_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return ((select (json_build_object(
            'id', t.id,
            'name', t.name,
            'code', t.code
        ))
            from public.language t
            where t.is_deleted = 0
              and t.id = i_language_id)::text);
end
$$;


ALTER FUNCTION crud.language_get(i_language_id bigint) OWNER TO postgres;

--
-- Name: language_update(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.language_update(data_params text, session_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    json_data  json;
    t_language record;
    dto        utils.update_language_dto;
BEGIN
    call helper.is_active(session_user_id);
    call helper.check_dataparam(data_params);
    json_data := data_params::json;
    dto := mapper.json_to_update_language_dto(json_data);

    call helper.check_admin_or_mentor(session_user_id);

    select * into t_language from public.language t where t.is_deleted = 0 and t.id = dto.id;
    if not FOUND then
        raise exception 'Language not found by id ''%''',dto.id;
    end if;


    if dto.name is null then
        dto.name := t_language.name;
    elseif exists(select t.id from public.language t where t.name ilike dto.name) then
        raise exception 'Language with name % already exist',t_language.name;
    end if;

    if dto.code is null then
        dto.code := t_language.code;
    elseif exists(select t.id from public.language t where t.code ilike dto.code) then
        raise exception 'Code % already exists ',dto.code;
    end if;
   
    update public.language
    set name       = dto.name,
        code       = dto.code,
        updated_at = now(),
        updated_by = session_user_id
    where id = dto.id;
    return row_to_json(row(t_language.code,t_language.name,t_language.id));
END
$$;


ALTER FUNCTION crud.language_update(data_params text, session_user_id bigint) OWNER TO postgres;

--
-- Name: languages_get(); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.languages_get() RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return ((select json_agg(json_build_object(
            'id', t.id,
            'name', t.name,
            'code', t.code
        ))
             from public.language t
             where t.is_deleted = 0)::text);
end
$$;


ALTER FUNCTION crud.languages_get() OWNER TO postgres;

--
-- Name: level_create(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.level_create(dataparam text DEFAULT NULL::text, i_user_id bigint DEFAULT NULL::bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    datajson     json;
    dto          utils.level_create_dto;
    power_number int;
    level_id     int default -1;

begin


    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

    datajson := dataparam::json;
    dto := mapper.level_to_create_dto(dataparam);


    call helper.check_for_null_or_length_zero(dto.level_name::text, 'Please check level name');
    call helper.check_for_null_or_length_zero(dto.category_id::text, 'Category id is invalid ');
    call helper.check_admin_or_mentor(i_user_id);

    if not exists(select t.id from public.category t where is_deleted = 0 and t.id = dto.category_id) then
        raise exception 'Category not found with this % id',dto.category_id; -- is it better to call get_category(id)?
    end if;


    if exists(select id
              from public.level t
              where t.level_name ILIKE dto.level_name
                and t.category_id = dto.category_id) then
        raise exception '''%'' level name already exists', dto.level_name;
    end if;


    insert into public.level(level_name, category_id, created_by)
    values (dto.level_name, dto.category_id, i_user_id)
    returning id into level_id;


    select count(*) into power_number from public.level where category_id = dto.category_id;
    
    update public.level set power = power_number where id = level_id;


    return level_id;

end;
$$;


ALTER FUNCTION crud.level_create(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: level_delete(smallint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.level_delete(i_level_id smallint, session_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    levelJsonb jsonb;
BEGIN

    call helper.is_active(session_user_id);
    call helper.check_admin_or_mentor(session_user_id);
    call helper.check_for_null_or_length_zero(i_level_id::text, 'Level id is invalid');

    levelJsonb := crud.level_get(i_level_id);

    if levelJsonb ->> 'level_name' is null then
        raise exception 'Level not found by ''%'' id ', i_level_id;
    end if;

    update public.level l set is_deleted = 1 where l.id = i_level_id;

    return levelJsonb;
end;
$$;


ALTER FUNCTION crud.level_delete(i_level_id smallint, session_user_id bigint) OWNER TO postgres;

--
-- Name: level_get(integer); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.level_get(i_level_id integer) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_level record;
BEGIN

    select * into r_level from public.level l where l.is_deleted = 0 and l.id = i_level_id;
    if not FOUND then
        return null;
    end if;


    return (select json_build_object(
                           'level_name', r_level.level_name,
                           'category_id', r_level.category_id,
                           'order', r_level.power,
                           'created_at', r_level.created_at,
                           'created_by', r_level.created_by
                       ));

end;
$$;


ALTER FUNCTION crud.level_get(i_level_id integer) OWNER TO postgres;

--
-- Name: level_update(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.level_update(dataparam text, i_user_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    levelJsonb jsonb;
    dto        utils.level_update_dto;

BEGIN
    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

    dto := mapper.level_to_update_dto(dataparam);

    call helper.check_for_null_or_length_zero(dto.level_id::text, 'Please check level id');
    call helper.check_admin_or_mentor(i_user_id);

    levelJsonb := crud.level_get(dto.level_id);

    if not levelJsonb ->> 'label_name' is null then
        raise exception 'Level not found by ''%''' , dto.level_id
            using hint = 'Please check level id';
    end if;


    if dto.power is not null and not crud.set_level_order(dto.level_id, dto.power) then
        raise exception 'order went wrong!';
    end if;
    

    if dto.level_name is null then
        dto.level_name = levelJsonb ->> 'level_name';
    end if;

    levelJsonb := crud.level_get(dto.level_id);


    update public.level
    set level_name = dto.level_name,
        updated_by = i_user_id,
        updated_at = now()
    where public.level.id = dto.level_id;


    return levelJsonb::text;

END
$$;


ALTER FUNCTION crud.level_update(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: levels_get(); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.levels_get() RETURNS text
    LANGUAGE plpgsql
    AS $$
Declare
begin

    return (select json_agg(crud.level_get(l.id))
            from (select * from public.level l where is_deleted = 0) as l);

end;
$$;


ALTER FUNCTION crud.levels_get() OWNER TO postgres;

--
-- Name: question_create(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.question_create(dataparam text, i_user_id bigint) RETURNS bigint[]
    LANGUAGE plpgsql
    AS $$

declare
    dto_array    jsonb;
    question_dto jsonb;
    variant      jsonb;
    variantId    bigint;
    variants     jsonb;
    questionId   bigint;
    categoryId   int;
    levelId      int;
    questionBody text;
    question_ids bigint[];
begin

    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

    dto_array := dataparam::jsonb;


    for question_dto in select jsonb_array_elements(dto_array)
        loop

            categoryId = question_dto ->> 'category_id';
            levelId = question_dto ->> 'level_id';
            questionBody = question_dto ->> 'question_body';
            variants = question_dto -> 'variants';


            raise info 'variants=%',variants;
            raise info 'type of=%',pg_typeof(variants);


            if exists(select t.id
                      from public.level t
                      where t.category_id = categoryId
                        and t.id = levelId)
            then
                insert into public.question(question_body, category_id, level_id, created_by)
                values (questionBody, categoryId, levelId, i_user_id)
                returning id into questionId;

                for variant in select jsonb_array_elements(variants::jsonb)
                    loop
                    
                    raise info 'variant=%, question_id=%, variant_body=%',variant,questionId,variant->>'variant_body';

                        insert into public.variant (question_id, body, is_correct, created_by)
                        values (questionId, (variant ->> 'variant_body'),
                                (variant -> 'is_correct')::bool, i_user_id)
                        returning id into variantId;
                        raise info 'variant_id= %',variantId;

                    end loop;

                question_ids := array_append(question_ids, questionId);

            end if;
        end loop;


    return coalesce(question_ids, array []::bigint[]);

end ;

$$;


ALTER FUNCTION crud.question_create(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: question_delete(bigint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.question_delete(i_question_id bigint, i_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$

declare
    questionJsonb jsonb;
begin

    call helper.is_active(i_user_id);
    call helper.check_admin_or_mentor(i_user_id);


    questionJsonb := crud.question_get(i_question_id);

    if questionJsonb ->> 'question_body' is null then
        raise exception 'Question not found with this % id ',i_question_id;
    end if;

    update public.question set is_deleted=1, updated_by=i_user_id, updated_at=now() where id = i_question_id;

    return questionJsonb;

end
$$;


ALTER FUNCTION crud.question_delete(i_question_id bigint, i_user_id bigint) OWNER TO postgres;

--
-- Name: question_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.question_get(i_question_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
    r_question record;
BEGIN

    if i_question_id is null then
        return null;
    end if;

    select * into r_question from public.question q where q.id = i_question_id and is_deleted = 0;

    return jsonb_build_object(
            'question_id', r_question.id,
            'question_body', r_question.question_body,
            'question_category', crud.category_get(r_question.category_id::smallint),
            'question_level', crud.level_get(r_question.level_id),
            'variants', crud.variants_get(r_question.id)
        );

END;
$$;


ALTER FUNCTION crud.question_get(i_question_id bigint) OWNER TO postgres;

--
-- Name: question_update(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.question_update(dataparam text, i_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
    dto        utils.question_update_dto;
    r_question record;
begin


    call helper.is_active(i_user_id);
    call helper.check_dataparam(dataparam);
    call helper.check_admin_or_mentor(i_user_id);

    dto := mapper.to_question_update_dto(dataparam::jsonb);

    select * into r_question from public.question t where t.id = dto.question_id;

    if not FOUND then
        raise exception 'Cannot find question with this % id',dto.question_id;
    end if;

    if dto.question_body is null then
        dto.question_body := r_question.question_body::text;
    end if;


    if dto.level_id is null then
        dto.level_id := r_question.level_id;
    else
        if not exists(select t.id
                      from public.level t
                      where t.id = dto.level_id
                        and t.category_id = r_question.category_id) then
            raise exception 'This level does not belong to this % category',r_question.category_id;
        end if;
    end if;

    update public.question
    set question_body=dto.question_body,
        level_id=dto.level_id,
        updated_at=now(),
        updated_by=i_user_id
    where id = dto.question_id;

    return to_jsonb(r_question);

end
$$;


ALTER FUNCTION crud.question_update(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: questions_get(smallint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.questions_get(i_category_id smallint) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
BEGIN
    
    return coalesce(
            (select json_agg(crud.question_get(t.id)) from public.question t where t.category_id = i_category_id),
            '[]');

END;
$$;


ALTER FUNCTION crud.questions_get(i_category_id smallint) OWNER TO postgres;

--
-- Name: quiz_finish(integer, integer); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_finish(quiz_id integer, user_id integer) RETURNS text
    LANGUAGE plpgsql
    AS $$

declare
    r_quiz record;
begin


    select * into r_quiz from public.quiz_history q where q.id = quiz_id and q.finished_at is null;

    if not found then
        raise exception 'quiz is not found or expired';
    end if;

    if r_quiz.user_id <> user_id and helper.hasanyrole('ADMIN#MENTOR#SUPERADMIN', user_id) is false then
        raise exception 'Permission denied!';
    end if;

    select count(*) into r_quiz.correct_answers from public.quiz_question qq where qq.correct;

    update public.quiz_history qh
    set correct_answers=r_quiz.correct_answers,
        finished_at=now()
    where qh.id = quiz_id
    returning * into r_quiz;


    return r_quiz::text;

end
$$;


ALTER FUNCTION crud.quiz_finish(quiz_id integer, user_id integer) OWNER TO postgres;

--
-- Name: quiz_generate(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_generate(dataparam text, i_user_id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
    dto          utils.get_test;
    question_ids bigint[];
    quizid       bigint;
    questionid   bigint;
begin


    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

    dto := mapper.json_to_get_test(dataparam);

    question_ids := array_agg(t.id)
                    from (select q.id
                          from public.question q
                          where q.category_id = dto.category_id
                            and q.level_id = dto.level_id
                            and q.is_deleted = 0
                            and jsonb_array_length(crud.variants_get(q.id)) > 0
                          order by random()) t;


    if array_length(question_ids, 1) < dto.number_of_questions or dto.number_of_questions < 1 then
        raise exception 'There is no such questions %',dto.number_of_questions;
    end if;

    insert into public.quiz_history(user_id, question_count)
    values (i_user_id, array_length(question_ids, 1))
    returning id into quizid;

    foreach questionid in array question_ids
        loop
            insert into public.quiz_question(quiz_id, question_id) values (quizid, questionid);
        end loop;


    return quizid;
end
$$;


ALTER FUNCTION crud.quiz_generate(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: quiz_histories_get(); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_histories_get() RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return (select json_agg(json_build_object(
            'Id', q.id,
            'userId', q.user_id,
            'userAnswers', q.user_answers,
            'max_questions', q.question_count,
            'correctAnswers', q.correct_answers))
                     from public.quiz_history q
                    where q.is_deleted = 0
                    group by q.created_at
                     order by q.created_at)::text;


end
$$;


ALTER FUNCTION crud.quiz_histories_get() OWNER TO postgres;

--
-- Name: quiz_history_create(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_history_create(dataparam text DEFAULT NULL::text, i_user_id bigint DEFAULT NULL::bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
    newId                    bigint;
    dto_array                jsonb;
    dto                      jsonb;
    ids                      bigint[];
    number_of_questions      smallint default 0;
    number_of_correct_answer smallint default 0;

begin
    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);

--     dto_array = mapper.to_quiz_history_create_dto(dataparam::jsonb);
--

    dto_array:=dataparam::jsonb;
    raise info '% array',dto_array;

    for dto in select jsonb_array_elements(dto_array)
        loop

            if helper.check_user_answer(dto) then
                number_of_correct_answer := number_of_correct_answer + 1;
            end if;

        end loop;

    raise info 'jsonlength=%',jsonb_array_length(dto_array);
    insert into public.quiz_history(user_id, user_answers, correct_answers, question_count)
    values (i_user_id, dto_array, number_of_correct_answer, jsonb_array_length(dto_array))
    returning id into newId;


    return newId;
end
$$;


ALTER FUNCTION crud.quiz_history_create(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: quiz_history_delete(bigint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_history_delete(i_quiz_history_id bigint DEFAULT NULL::bigint, session_user_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN

    call helper.check_for_null_or_length_zero(i_quiz_history_id::text, 'Quiz history id is invalid');
    call helper.check_for_null_or_length_zero(session_user_id::text, 'User id is invalid');
    call helper.is_active(session_user_id);
    call helper.check_admin_or_mentor(session_user_id);

    if not exists(select * from public.quiz_history q where q.is_deleted = 0 and q.id = i_quiz_history_id) then
        raise exception 'Quiz history is not found with id "%"',i_quiz_history_id;
        end if;

    update public.quiz_history q set is_deleted = 1 where q.id = i_quiz_history_id;

    return (select json_agg(json_build_object(
            'user_id', q.user_id,
            'user_answers', q.user_answers,
            'correct_answers', q.correct_answers,
            'max_questions', q.question_count,
            'is_deleted', q.is_deleted))
                     from public.quiz_history q
                     where q.id = i_quiz_history_id)::text;

end
$$;


ALTER FUNCTION crud.quiz_history_delete(i_quiz_history_id bigint, session_user_id bigint) OWNER TO postgres;

--
-- Name: quiz_history_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_history_get(i_quiz_history_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    call helper.check_for_null_or_length_zero(i_quiz_history_id::text, 'Quiz history id is invalid');

    if not exists(select * from public.quiz_history q where q.is_deleted = 0 and q.id = i_quiz_history_id) then
        raise exception 'Quiz history is not found with id "%"',i_quiz_history_id;
    end if;

    return (select json_agg(json_build_object(
            'userId', q.user_id,
            'userAnswers', q.user_answers,
            'max_questions', q.question_count,
            'correctAnswers', q.correct_answers))
                     from public.quiz_history q
                     where q.id = i_quiz_history_id)::text;

end
$$;


ALTER FUNCTION crud.quiz_history_get(i_quiz_history_id bigint) OWNER TO postgres;

--
-- Name: quiz_history_user_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_history_user_get(userid bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    call helper.is_active(userid);

    return (select json_agg(json_build_object(
            'userId', q.user_id,
            'userAnswers', q.user_answers,
            'maxQuestions', q.question_count,
            'correctAnswers', q.correct_answers,
            'created_at', q.created_at))
                     from public.quiz_history q
                     where  q.is_deleted=0 and q.user_id = userid
                    group by q.created_at
                    order by q.created_at)::text;
end;
$$;


ALTER FUNCTION crud.quiz_history_user_get(userid bigint) OWNER TO postgres;

--
-- Name: quiz_question_submit(text, integer); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_question_submit(dataparam text, user_id integer) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
    dataJson jsonb;
    dto      utils.submit_answer;

begin

    call helper.is_active(user_id);
    call helper.check_dataparam(dataparam);
    dataJson := dataparam::json;

    dto.quizid := dataJson ->> 'quizid';
    dto.questionid := dataJson ->> 'questionid';
    dto.choices := array_agg(t::bigint) from jsonb_array_elements(dataJson -> 'choices') t;


    call helper.check_for_null_or_length_zero(dto.quizid::text);
    call helper.check_for_null_or_length_zero(dto.questionid::text);
    call helper.check_for_null_or_length_zero(dto.choices::text);

    if array_length(dto.choices, 1) <> 0 then

        update public.quiz_question qq
        set correct=crud.iscorrect(dto.questionid, dto.choices),
            user_choices=dto.choices
        where qq.quiz_id = dto.quizid
          and qq.question_id = dto.questionid;

    end if;

    return
        crud.question_get((select qq.question_id
                           from public.quiz_question qq
                           where qq.quiz_id = dto.quizid
                             and correct is null
                             and qq.question_id <> dto.questionid
                           limit 1));


end
$$;


ALTER FUNCTION crud.quiz_question_submit(dataparam text, user_id integer) OWNER TO postgres;

--
-- Name: quiz_start(bigint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.quiz_start(i_quiz_id bigint, i_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin

    call helper.is_active(i_user_id);
    if not exists(select q.id
                  from public.quiz_history q
                  where q.user_id = i_user_id
                    and q.started_at is null
                    and q.id = i_quiz_id) then
        raise exception 'Quiz not found!';
    end if;

    update public.quiz_history qh set started_at=current_timestamp where qh.id = i_quiz_id;

    return crud.question_get((select qq.question_id from public.quiz_question qq where qq.quiz_id = i_quiz_id limit 1));


end;
$$;


ALTER FUNCTION crud.quiz_start(i_quiz_id bigint, i_user_id bigint) OWNER TO postgres;

--
-- Name: set_level_order(integer, integer); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.set_level_order(level_id integer, i_order integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$

declare
    oldOrder            int;
    ownerOrder          int;
    counterpartId       int;
    number_of_questions int;

begin


    ownerOrder := (select t.power from public.level t where t.id = level_id);
    counterpartId := (select t.id from public.level t order by power limit 1 offset i_order - 1);
    oldOrder := (select t.power from public.level t where t.id = counterpartId);

    number_of_questions :=
            (select count(*) over (partition by category_id) from public.level t where t.category_id = 9 limit 1);

    raise warning 'number of question % ',number_of_questions;
    raise warning 'order % ',i_order;

    if i_order > number_of_questions or i_order < 1 then
        return false;
    end if;


    update public.level set power=oldOrder where id = level_id;
    update public.level set power=ownerOrder where id = counterpartId;

    return true;


end;
$$;


ALTER FUNCTION crud.set_level_order(level_id integer, i_order integer) OWNER TO postgres;

--
-- Name: user_delete(bigint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.user_delete(user_id bigint, session_user_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    t_user record;
BEGIN
    call helper.is_active(user_id);
    call helper.is_active(session_user_id);

    select * into t_user from public.users usr where session_user_id = usr.id;

    if (helper.hasanyrole('ADMIN#SUPERADMIN', session_user_id) is false
        and t_user.id = user_id) is false then
        raise exception 'Permission denied' using hint = 'Only site administration or user can delete';
    end if;
    
    update public.users set is_deleted = 1 where id = user_id;
    return true;
END
$$;


ALTER FUNCTION crud.user_delete(user_id bigint, session_user_id bigint) OWNER TO postgres;

--
-- Name: user_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.user_get(i_user_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return ((select (json_build_object(
            'id', t.id,
            'fullname', t.fullname,
            'username', t.username,
            'email', t.email,
            'role', t.role,
            'created_at', t.created_at,
            'language_id', t."language_id"
        ))
             from public.users t
             where t.is_deleted = 0
               and t.id = i_user_id)::text);
end
$$;


ALTER FUNCTION crud.user_get(i_user_id bigint) OWNER TO postgres;

--
-- Name: user_login(character varying, character varying); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.user_login(uname character varying DEFAULT NULL::character varying, pswd character varying DEFAULT NULL::character varying) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
    t_user record;
begin

    select * into t_user from public.users t where t.username = lower(uname);

    if not FOUND then
        raise exception using message = 'Bad credentials password or username is invalid!';
    end if;

    if helper.match_password(pswd, t_user.password) is false then
        raise exception 'Bad credentials password or username is invalid!';
    end if;

    return json_build_object('id', t_user.id,
                             'username', t_user.username,
                             'language', crud.language_get(t_user.language_id)::jsonb,
                             'role', t_user.role)::text;

end
$$;


ALTER FUNCTION crud.user_login(uname character varying, pswd character varying) OWNER TO postgres;

--
-- Name: user_register(text); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.user_register(dataparam text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    newId  int4;
    t_user record;
    dto    utils.create_user_dto;
begin

    call helper.check_dataparam(dataparam);

    dto := mapper.json_to_create_user_dto(dataparam::json);


    call helper.check_for_null_or_length_zero(dto.email, 'Email is invalid');
    call helper.check_for_null_or_length_zero(dto.password, 'Password is invalid');
    call helper.check_for_null_or_length_zero(dto.username, 'Username is invalid');
    call helper.check_for_null_or_length_zero(dto.full_name, 'Full name is invalid');
    call helper.check_for_null_or_length_zero(dto.language_id::text, 'Language is invalid');

    select *
    into t_user
    from public.users t
    where t.username = lower(dto.username);

    if FOUND then
        raise using message = 'User already exists';
    end if;


    if not exists(select * from public.language l where l.id = dto.language_id) then
        dto.language_id := 1;
    end if;

    if exists(select t.id from public.users t where t.email ilike dto.email) then
        raise exception 'User with this email % already registered!',dto.email;
    end if;

    dto.role := 'USER';

    insert into public.users (username, email, password, fullname, role, language_id)
    values (lower(dto.username),
            dto.email,
            helper.encode_password(dto.password),
            dto.full_name,
            dto.role::utils.user_role,
            dto.language_id)
    returning id into newId;

    return newId;
end
$$;


ALTER FUNCTION crud.user_register(dataparam text) OWNER TO postgres;

--
-- Name: user_update(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.user_update(data_params text, session_user_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    t_user record;
    dto    utils.update_user_dto;
BEGIN

    call helper.is_active(session_user_id);
    call helper.check_dataparam(data_params);

    dto := mapper.json_to_update_user_dto(data_params::json);

    if dto.id = session_user_id is false and
       helper.hasanyrole('SUPER_ADMIN#ADMIN', session_user_id) is false then
        raise exception 'Permission denied' using hint = 'Only user or Site administration can edit';
    end if;

    select * into t_user from public.users t where t.is_deleted = 0 and t.id = dto.id;
    if not FOUND then
        raise exception 'User not found by id ''%''',dto.id;
    end if;

    if dto.username is null then
        dto.username := t_user.username;
    else
        if exists(select * from public.users usr where usr.username ilike dto.username) then
            raise exception 'User with username % already exist',t_user.username;
        end if;
    end if;

    if dto.full_name is null or length(trim(dto.full_name)) = 0 then
        dto.full_name := t_user.fullname;
    end if;

    if dto.password is null then
        dto.password := t_user.password;
    else
        dto.password = helper.crypt_password(dto.password);
    end if;

    if dto.email is null then
        dto.email := t_user.email; -- changing email must be another complete method
    else
        if helper.check_email(dto.email) is false then
            raise exception 'Wrong email format % ',dto.email using detail = 'Email will be as: example@gmail.com';
        end if;

        if exists(select * from public.users usr where usr.email ilike dto.email) then
            raise exception 'User with email % already exist',t_user.email;
        end if;
    end if;


    if dto.language_id is null then
        dto.language_id := t_user.language_id;
    else
        if not exists(select tl.id from public.language tl where tl.id = dto.language_id) then
            raise exception 'Wrong language id' using detail = 'User update language error';
        end if;
    end if;

    if dto.role is null then
        dto.role = t_user.role;
    else
        if  exists(select * from pg_enum where enumlabel = upper(dto.role::varchar)) is false or
           helper.hasanyrole('SUPER_ADMIN', session_user_id) is false then
            raise exception 'Malformed activity found in user %',dto.email;
        end if;
    end if;


    update public.users
    set fullname    = dto.full_name,
        username    = dto.username,
        password    = dto.password,
        email       = dto.email,
        language_id = dto.language_id,
        role        = cast(dto.role as utils.user_role),
        updated_at=now(),
        updated_by=session_user_id
    where id = dto.id;

    return true;
END
$$;


ALTER FUNCTION crud.user_update(data_params text, session_user_id bigint) OWNER TO postgres;

--
-- Name: users_get(); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.users_get() RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return coalesce((select json_agg(crud.user_get(t.id)::jsonb)
             from public.users t
             where t.is_deleted = 0)::text,'[]');
end
$$;


ALTER FUNCTION crud.users_get() OWNER TO postgres;

--
-- Name: variant_create(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.variant_create(dataparam text, i_user_id bigint) RETURNS bigint[]
    LANGUAGE plpgsql
    AS $$
declare
    dto_arr    utils.variant_create[];
    dto        utils.variant_create;
    variantId  bigint;
    variantIds bigint[];
begin

    call helper.check_dataparam(dataparam);
    dto_arr := mapper.to_variants(dataparam::jsonb);

    if dto_arr is null then
        return array []::bigint[];
    end if;

    call helper.check_admin_or_mentor(i_user_id);

    foreach dto in array dto_arr
        loop

            insert into public.variant(question_id, body, is_correct, created_by)
            values (dto.question_id, dto.variant_body, dto.is_correct, i_user_id)
            returning id into variantId;
            variantIds = array_append(variantIds, variantId);

        end loop;

    return variantIds;


end;
$$;


ALTER FUNCTION crud.variant_create(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: variant_delete(bigint, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.variant_delete(i_variant_id bigint, i_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$

declare
    variantJsonb jsonb;
begin

    call helper.is_active(i_user_id);
    call helper.check_admin_or_mentor(i_user_id);


    variantJsonb := crud.variant_get(i_variant_id);

    if variantJsonb ->> 'body' is null then
        raise exception 'Variant not found with this % id ',i_variant_id;
    end if;

    update public.variant set is_deleted=1, updated_by=i_user_id, updated_at=now() where id = i_variant_id;

    return variantJsonb;

end
$$;


ALTER FUNCTION crud.variant_delete(i_variant_id bigint, i_user_id bigint) OWNER TO postgres;

--
-- Name: variant_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.variant_get(i_variant_id bigint DEFAULT NULL::bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
begin
    return ((select (json_build_object(
            'id', t.id,
            'body', t.body,
            'is_correct', t.is_correct
        ))
             from public.variant t
             where t.is_deleted = 0
               and t.id = i_variant_id));
end
$$;


ALTER FUNCTION crud.variant_get(i_variant_id bigint) OWNER TO postgres;

--
-- Name: variant_update(text, bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.variant_update(dataparam text, i_user_id bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
    dto          utils.variant_update_dto;
    variantJsonb jsonb;
begin


    call helper.check_dataparam(dataparam);
    call helper.is_active(i_user_id);
    call helper.check_admin_or_mentor(i_user_id);

    dto := mapper.to_variant_update_dto(dataparam::jsonb);

    if dto.variant_id is null then
        return dataparam;
    end if;

    variantJsonb := crud.variant_get(dto.variant_id);

    if dto.variant_body is null then
        dto.variant_body := variantJsonb ->> 'body';
    end if;

    if dto.is_correct is null then
        dto.is_correct := variantJsonb ->> 'is_correct';
    end if;


    update public.variant
    set body=dto.variant_body,
        is_correct=dto.is_correct,
        updated_by=i_user_id,
        updated_at=now()
    where id = dto.variant_id;

    return variantJsonb;

end;
$$;


ALTER FUNCTION crud.variant_update(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: variants_get(bigint); Type: FUNCTION; Schema: crud; Owner: postgres
--

CREATE FUNCTION crud.variants_get(i_question_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
begin
    return coalesce((select json_agg(crud.variant_get(t.id))
             from public.variant t
             where t.is_deleted = 0
               and t.question_id = i_question_id order by random())::text,'[]');
end
$$;


ALTER FUNCTION crud.variants_get(i_question_id bigint) OWNER TO postgres;

--
-- Name: check_admin_or_mentor(bigint); Type: PROCEDURE; Schema: helper; Owner: postgres
--

CREATE PROCEDURE helper.check_admin_or_mentor(IN user_id bigint DEFAULT NULL::bigint)
    LANGUAGE plpgsql
    AS $$
    Begin
    if helper.hasrole(user_id, 'ADMIN') is false
        and helper.hasrole(user_id, 'MENTOR') is false then
        raise exception 'Permission denied'
            using hint = 'Only ADMIN or MENTOR can delete category';
    end if;
end;
$$;


ALTER PROCEDURE helper.check_admin_or_mentor(IN user_id bigint) OWNER TO postgres;

--
-- Name: check_dataparam(text); Type: PROCEDURE; Schema: helper; Owner: postgres
--

CREATE PROCEDURE helper.check_dataparam(IN dataparam text)
    LANGUAGE plpgsql
    AS $$
begin
    if dataparam is null or dataparam = '{}'::text then
        raise exception 'Data param is invalid!';
    end if;
end;
$$;


ALTER PROCEDURE helper.check_dataparam(IN dataparam text) OWNER TO postgres;

--
-- Name: check_email(character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.check_email(u_email character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE
    em      varchar;
    pattern varchar := '^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-]+)(\.[a-zA-Z]{2,5}){1,2}$';
BEGIN
    if u_email is null or trim(u_email) ilike '' then
        raise exception 'Email can not be null or empty' using hint = 'Check email';
    end if;
    return u_email ~* pattern;
END
$_$;


ALTER FUNCTION helper.check_email(u_email character varying) OWNER TO postgres;

--
-- Name: check_for_null_or_length_zero(text, character varying); Type: PROCEDURE; Schema: helper; Owner: postgres
--

CREATE PROCEDURE helper.check_for_null_or_length_zero(IN content text, IN message character varying DEFAULT 'Invalid data'::character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN

    if content is null or
       length(trim(content)) = 0 then
        raise exception '%',message;
    end if;
END;
$$;


ALTER PROCEDURE helper.check_for_null_or_length_zero(IN content text, IN message character varying) OWNER TO postgres;

--
-- Name: check_input_is_null(character varying, character varying); Type: PROCEDURE; Schema: helper; Owner: postgres
--

CREATE PROCEDURE helper.check_input_is_null(IN i_input character varying, IN column_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    if i_input is null or trim(i_input) ilike '' then
        raise exception '% can not be null' , column_name;
    end if;
END
$$;


ALTER PROCEDURE helper.check_input_is_null(IN i_input character varying, IN column_name character varying) OWNER TO postgres;

--
-- Name: check_user_answer(jsonb); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.check_user_answer(dto jsonb) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    question                 jsonb;
    user_answers             jsonb;
    question_correct_answers jsonb;
begin

    question_correct_answers := json_agg(id)
                                from public.variant t
                                where t.question_id = (dto ->> 'question_id')::bigint
                                  and t.is_correct;

    raise info '%m_array',question_correct_answers;

    raise info 'user answers: %',dto;

    user_answers = array_agg(t::bigint)
                   from jsonb_array_elements(dto -> 'user_answers') as t;


    raise info 'm_array=%, user_ans=%',m_array,user_answers;

--     select array_agg(t) from (select jsonb_array_elements(dto.user_answers)) as t;

    return (m_array && user_answers);
end;
$$;


ALTER FUNCTION helper.check_user_answer(dto jsonb) OWNER TO postgres;

--
-- Name: check_username(character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.check_username(i_username character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    if i_username is null then
        raise exception 'Username can not be null';
    end if;
    return true;
END
$$;


ALTER FUNCTION helper.check_username(i_username character varying) OWNER TO postgres;

--
-- Name: crypt_password(character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.crypt_password(password character varying DEFAULT NULL::character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
    if password is null then
        raise exception 'Password can not be null' using hint = 'User registration';
    end if;
    return utils.crypt(password, utils.gen_salt('bf', 4));
END
$$;


ALTER FUNCTION helper.crypt_password(password character varying) OWNER TO postgres;

--
-- Name: encode_password(character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.encode_password(rawpassword character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
begin
    if rawPassword is null then
        raise exception 'Invalid Password null';
    end if;
    return utils.crypt(rawPassword, utils.gen_salt('bf', 4));
end
$$;


ALTER FUNCTION helper.encode_password(rawpassword character varying) OWNER TO postgres;

--
-- Name: get_user(bigint); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.get_user(i_user_id bigint DEFAULT NULL::bigint) RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return coalesce(((select (json_build_object(
            'id', t.id,
            'fullname', t.fullname,
            'username', t.username,
            'email', t.email,
            'role', t.role,
            'created_at', t.created_at,
            'language_id', t."language_id"
        ))
             from public.users t
             where t.is_deleted = 0
               and t.id = i_user_id)::text),'[]');
end
$$;


ALTER FUNCTION helper.get_user(i_user_id bigint) OWNER TO postgres;

--
-- Name: get_users(); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.get_users() RETURNS text
    LANGUAGE plpgsql
    AS $$
begin
    return coalesce(((select json_agg(json_build_object(
            'id', t.id,
            'fullname', t.fullname,
            'username', t.username,
            'email', t.email,
            'role', t.role,
            'created_at', t.created_at,
            'language_id', t."language_id"
        ))
                      from public.users t
                      where t.is_deleted = 0)::text), '[]');
end
$$;


ALTER FUNCTION helper.get_users() OWNER TO postgres;

--
-- Name: hasanyrole(character varying, bigint, character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.hasanyrole(roles character varying, user_id bigint, dilim character varying DEFAULT '#'::character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    userrole varchar;
begin

    select u.role into userrole from public.users u where u.id = user_id;

    return array_position(regexp_split_to_array(roles, dilim), userrole) is not null;


end;
$$;


ALTER FUNCTION helper.hasanyrole(roles character varying, user_id bigint, dilim character varying) OWNER TO postgres;

--
-- Name: hasrole(bigint, character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.hasrole(userid bigint DEFAULT NULL::bigint, role character varying DEFAULT NULL::character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    t_user record;
BEGIN
    if userid is null or role is null then
        return false;
    end if;
    select * into t_user from public.users t where t.is_deleted = 0 and t.id = userid;
    return FOUND and t_user.role::text ilike role;
END
$$;


ALTER FUNCTION helper.hasrole(userid bigint, role character varying) OWNER TO postgres;

--
-- Name: is_active(bigint); Type: PROCEDURE; Schema: helper; Owner: postgres
--

CREATE PROCEDURE helper.is_active(IN i_user_id bigint DEFAULT NULL::bigint)
    LANGUAGE plpgsql
    AS $$
begin

    if i_user_id is null then
        raise exception 'User not found with this % id',i_user_id;
    end if;


    if not exists(select * from public.users u where u.id = i_user_id and is_deleted = 0) then
        raise exception 'User not found with % this id',i_user_id;
    end if;

    if not found then

    end if;



end;
$$;


ALTER PROCEDURE helper.is_active(IN i_user_id bigint) OWNER TO postgres;

--
-- Name: match_password(character varying, character varying); Type: FUNCTION; Schema: helper; Owner: postgres
--

CREATE FUNCTION helper.match_password(password character varying, coded_password character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    if password is null then
        raise exception 'Password can not be null' using hint = 'User registration';
    end if;
    if coded_password is null then
        raise exception 'Coded password can not be null' using hint = 'User registration',
            detail = 'match_password function';
    end if;
    return coded_password = utils.crypt(password, coded_password);
END
$$;


ALTER FUNCTION helper.match_password(password character varying, coded_password character varying) OWNER TO postgres;

--
-- Name: set_correct_answers_on_question(bigint); Type: PROCEDURE; Schema: helper; Owner: postgres
--

CREATE PROCEDURE helper.set_correct_answers_on_question(IN i_question_id bigint)
    LANGUAGE plpgsql
    AS $$
begin

    update public.question
    set correct_answers=((select count(*) from public.variant v where v.question_id = i_question_id and is_correct))
    where id = i_question_id;

end;
$$;


ALTER PROCEDURE helper.set_correct_answers_on_question(IN i_question_id bigint) OWNER TO postgres;

--
-- Name: log_category_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_category_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.category_audits_table(category_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.category_audits_table(category_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.category_name <> OLD.category_name THEN
        INSERT INTO logs.category_audits_table(CATEGORY_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id,row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'CATEGORY_NAME');
    END IF;
    IF NEW.is_deleted <> OLD.is_deleted THEN
        INSERT INTO logs.category_audits_table(CATEGORY_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'IS_DELETED');
    END IF;
    IF NEW.language_id <> OLD.language_id THEN
        INSERT INTO logs.category_audits_table(CATEGORY_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'LANGUAGE_ID');
    END IF;
    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_category_changes() OWNER TO postgres;

--
-- Name: log_language_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_language_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.language_audits_table(language_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.language_audits_table(language_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.name <> OLD.name THEN
        INSERT INTO logs.language_audits_table(language_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'name');
    END IF;
    IF NEW.code <> OLD.code THEN
        INSERT INTO logs.language_audits_table(language_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'code');
    END IF;
    IF NEW.is_deleted <> OLD.is_deleted THEN
        INSERT INTO logs.language_audits_table(language_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'is_deleted');
    END IF;
    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_language_changes() OWNER TO postgres;

--
-- Name: log_level_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_level_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.level_audits_table(level_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.level_audits_table(level_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.level_name <> OLD.level_name THEN
        INSERT INTO logs.level_audits_table(level_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'level_name');
    END IF;
    IF NEW.power <> OLD.power THEN
        INSERT INTO logs.level_audits_table(level_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new),
                tg_op::varchar, now(),
                old.updated_by, 'power');
    END IF;
    IF NEW.category_id <> OLD.category_id THEN
        INSERT INTO logs.level_audits_table(level_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'level_name');
    END IF;
    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_level_changes() OWNER TO postgres;

--
-- Name: log_question_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_question_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.question_audits_table(question_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        call helper.set_correct_answers_on_question(new.id);
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.question_audits_table(question_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.question_body <> OLD.question_body THEN
        INSERT INTO logs.question_audits_table(question_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'question_body');
    END IF;
    IF NEW.level_id <> OLD.level_id THEN
        INSERT INTO logs.question_audits_table(question_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new),
                tg_op::varchar, now(),
                old.updated_by, 'level_id');
    END IF;
    IF NEW.is_deleted <> OLD.is_deleted THEN
        INSERT INTO logs.question_audits_table(question_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new),
                tg_op::varchar, now(),
                old.updated_by, 'is_deleted');
    END IF;
    IF NEW.category_id <> OLD.category_id THEN
        INSERT INTO logs.question_audits_table(question_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'category_id');
    END IF;
    IF NEW.correct_answers <> OLD.correct_answers THEN
        INSERT INTO logs.question_audits_table(question_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                               dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'correct_answers');
    END IF;

    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_question_changes() OWNER TO postgres;

--
-- Name: log_quiz_history_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_quiz_history_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.quiz_history_audits_table(quiz_history_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.quiz_history_audits_table(quiz_history_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.user_answers <> OLD.user_answers THEN
        INSERT INTO logs.quiz_history_audits_table(quiz_history_id, old_row_data, new_row_data, dml_type,
                                                   dml_time_stamp,
                                                   dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'user_answers');
    END IF;
    IF NEW.correct_answers <> OLD.correct_answers THEN
        INSERT INTO logs.quiz_history_audits_table(quiz_history_id, old_row_data, new_row_data, dml_type,
                                                   dml_time_stamp,
                                                   dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'correct_answers');
    END IF;
    IF NEW.is_deleted <> OLD.is_deleted THEN
        INSERT INTO logs.quiz_history_audits_table(quiz_history_id, old_row_data, new_row_data, dml_type,
                                                   dml_time_stamp,
                                                   dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new),
                tg_op::varchar, now(),
                old.updated_by, 'is_deleted');
    END IF;

    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_quiz_history_changes() OWNER TO postgres;

--
-- Name: log_user_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_user_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.users_audits_table(user_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.users_audits_table(user_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.username <> OLD.username THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'USERNAME');
    END IF;
    --todo password should encoded with Elshod's method
    IF NEW.password <> OLD.password THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'password');
    END IF;
    IF NEW.fullname <> OLD.fullname THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id,row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'fullName');
    END IF;
    IF NEW.email <> OLD.email THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id,row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'email');
    END IF;
    IF NEW.role <> OLD.role THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar,
                now(), old.updated_by,
                'role');
    END IF;
    IF NEW.is_deleted <> OLD.is_deleted THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'isdeleted');
    END IF;
    IF NEW.language_id <> OLD.language_id THEN
        INSERT INTO logs.users_audits_table(user_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                            dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'language_id');
    END IF;

    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_user_changes() OWNER TO postgres;

--
-- Name: log_variant_changes(); Type: FUNCTION; Schema: logs; Owner: postgres
--

CREATE FUNCTION logs.log_variant_changes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    if tg_op::varchar = 'INSERT' THEN
        INSERT INTO logs.variant_audits_table(variant_id, dml_type, dml_time_stamp)
        VALUES (NEW.id, tg_op::varchar, now());
        RETURN NEW;
    end if;
    if tg_op::varchar = 'DELETE' THEN
        INSERT INTO logs.variant_audits_table(variant_id, dml_type, dml_time_stamp)
        VALUES (old.id, tg_op::varchar, now());
        RETURN old;
    end if;
    IF NEW.body <> OLD.body THEN
        INSERT INTO logs.variant_audits_table(variant_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                              dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new), tg_op::varchar, now(),
                old.updated_by, 'body');
    END IF;
    IF NEW.is_correct <> OLD.is_correct THEN
        INSERT INTO logs.variant_audits_table(variant_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                              dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new),
                tg_op::varchar, now(),
                old.updated_by, 'is_correct');
    END IF;
    IF NEW.is_deleted <> OLD.is_deleted THEN
        INSERT INTO logs.variant_audits_table(variant_id, old_row_data, new_row_data, dml_type, dml_time_stamp,
                                              dml_created_by, row_name)
        VALUES (old.id, row_to_json(old),row_to_json(new),
                tg_op::varchar, now(),
                old.updated_by, 'is_deleted');
    END IF;

    RETURN NEW;
ENd
$$;


ALTER FUNCTION logs.log_variant_changes() OWNER TO postgres;

--
-- Name: json_to_create_language_dto(json); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.json_to_create_language_dto(json_data json) RETURNS utils.create_language_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    data utils.create_language_dto;
BEGIN
    data.code := json_data ->> 'code';
    data.name := json_data ->> 'name';
    return data;
END
$$;


ALTER FUNCTION mapper.json_to_create_language_dto(json_data json) OWNER TO postgres;

--
-- Name: json_to_create_user_dto(json); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.json_to_create_user_dto(json_data json) RETURNS utils.create_user_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    data utils.create_user_dto;
BEGIN
    data.full_name := json_data ->> 'full_name';
    data.username := json_data ->> 'username';
    data.email := json_data ->> 'email';
    data.password := json_data ->> 'password';
    data.language_id := json_data ->> 'language_id';
    data.role := json_data ->> 'role';
    return data;
END
$$;


ALTER FUNCTION mapper.json_to_create_user_dto(json_data json) OWNER TO postgres;

--
-- Name: json_to_get_test(text); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.json_to_get_test(dataparam text) RETURNS utils.get_test
    LANGUAGE plpgsql
    AS $$
DECLARE
    dataJson json;
    dto      utils.get_test;
BEGIN
    dataJson := dataparam::json;
    dto.category_id := dataJson ->> 'category_id';
    dto.level_id := dataJson ->> 'level_id';
    dto.number_of_questions := dataJson ->> 'number_of_questions';

    return dto;
end;
$$;


ALTER FUNCTION mapper.json_to_get_test(dataparam text) OWNER TO postgres;

--
-- Name: json_to_update_language_dto(json); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.json_to_update_language_dto(json_data json) RETURNS utils.update_language_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    data utils.update_language_dto;
BEGIN
    data.id := json_data ->> 'id';
    data.name := json_data ->> 'name';
    data.code := json_data ->> 'code';
    return data;
END
$$;


ALTER FUNCTION mapper.json_to_update_language_dto(json_data json) OWNER TO postgres;

--
-- Name: json_to_update_user_dto(json); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.json_to_update_user_dto(json_data json) RETURNS utils.update_user_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    data utils.update_user_dto;
BEGIN
    data.id := json_data ->> 'id';
    data.full_name := json_data ->> 'full_name';
    data.username := json_data ->> 'username';
    data.email := json_data ->> 'email';
    data.password := json_data ->> 'password';
    data.language_id := json_data ->> 'language_id';
    data.role := json_data ->> 'role';
    return data;
END
$$;


ALTER FUNCTION mapper.json_to_update_user_dto(json_data json) OWNER TO postgres;

--
-- Name: level_to_create_dto(text); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.level_to_create_dto(dataparam text DEFAULT NULL::text) RETURNS utils.level_create_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dataJson json;
    dto      utils.level_create_dto;
BEGIN


    dataJson := dataparam::json;
    dto.level_name := dataJson ->> 'level_name';
    dto.category_id := dataJson ->> 'category_id';

    return dto;
end;
$$;


ALTER FUNCTION mapper.level_to_create_dto(dataparam text) OWNER TO postgres;

--
-- Name: level_to_update_dto(text); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.level_to_update_dto(dataparam text DEFAULT NULL::text) RETURNS utils.level_update_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dataJson json;
    dto      utils.level_update_dto;
BEGIN


    dataJson := dataparam::json;
    dto.level_name := dataJson ->> 'level_name';
    dto.level_id := dataJson ->> 'level_id';
    dto.power := dataJson ->> 'order';

    return dto;
end;
$$;


ALTER FUNCTION mapper.level_to_update_dto(dataparam text) OWNER TO postgres;

--
-- Name: to_category_create_dto(text); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_category_create_dto(dataparam text DEFAULT NULL::text) RETURNS utils.category_create_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dataJson json;
    dto      utils.category_create_dto;
BEGIN
    dataJson := dataparam::json;
    dto.category_name := dataJson ->> 'category_name';
    dto.language_id := dataJson ->> 'language_id';

    return dto;
end;
$$;


ALTER FUNCTION mapper.to_category_create_dto(dataparam text) OWNER TO postgres;

--
-- Name: to_category_update_dto(text, bigint); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_category_update_dto(dataparam text, i_user_id bigint DEFAULT NULL::bigint) RETURNS utils.category_update_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dataJson json;
    dto      utils.category_update_dto;
BEGIN
    dataJson := dataparam::json;
    dto.category_name := dataJson->>'category_name';
    dto.category_id := dataJson->>'category_id';

    return dto;
end;
$$;


ALTER FUNCTION mapper.to_category_update_dto(dataparam text, i_user_id bigint) OWNER TO postgres;

--
-- Name: to_question_create_dto(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_question_create_dto(dataparam jsonb) RETURNS utils.question_create_dto
    LANGUAGE plpgsql
    AS $$
declare
    dto           utils.question_create_dto;
    questionJsonb jsonb;
    variantJsonb  jsonb;
    questions     jsonb ;
    variants      jsonb;


begin

    questions := dataparam -> 'questions';
    variants := dataparam -> 'variants';


    for questionJsonb in select jsonb_array_elements(questions)
        loop
            dto.questions := array_append(dto.questions, mapper.to_question_create(questionJsonb));
        end loop;

    for variantJsonb in select jsonb_array_elements(variants)
        loop
            dto.variants := array_append(dto.variants, mapper.to_variant_create(variantJsonb));
        end loop;


    dto.questions := array_remove(dto.questions, null);
    dto.variants := array_remove(dto.variants, null);


    if array_length(dto.questions, 1) = 0 then
        return null;
    end if;

    if array_length(dto.variants, 1) = 0 then
        dto.variants = null;
    end if;

    raise info '%',dto.questions;
    return dto;

exception
    when others
        then
            return dto;


end
$$;


ALTER FUNCTION mapper.to_question_create_dto(dataparam jsonb) OWNER TO postgres;

--
-- Name: to_question_update_dto(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_question_update_dto(dataparam jsonb) RETURNS utils.question_update_dto
    LANGUAGE plpgsql
    AS $$
declare
    dto utils.question_update_dto;
begin

    dto.level_id := dataparam ->> 'level_id';
    dto.question_body := dataparam ->> 'question_body';
    dto.question_id := dataparam ->> 'question_id';

    return dto;


end


$$;


ALTER FUNCTION mapper.to_question_update_dto(dataparam jsonb) OWNER TO postgres;

--
-- Name: to_quiz_history_create_dto(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_quiz_history_create_dto(dataparam jsonb DEFAULT NULL::jsonb) RETURNS utils.quiz_create_dto[]
    LANGUAGE plpgsql
    AS $$
DECLARE
    dataJson  json;
    dto_array utils.quiz_create_dto[];
    dto       utils.quiz_create_dto;
    quizJsonb jsonb;
    quizzes   jsonb;
BEGIN


    --     quizzes := dataparam;

    raise warning '%',quizzes;


    for quizJsonb in select jsonb_array_elements(dataparam)
        loop
        
            raise warning '%',quizJsonb;
            dto_array = array_append(dto_array, mapper.to_quiz_history_dto(quizJsonb));
        end loop;


    raise info '%m dto array',dto_array;

    return dto_array;

end;
$$;


ALTER FUNCTION mapper.to_quiz_history_create_dto(dataparam jsonb) OWNER TO postgres;

--
-- Name: to_quiz_history_dto(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_quiz_history_dto(dataparam jsonb DEFAULT NULL::jsonb) RETURNS utils.quiz_create_dto
    LANGUAGE plpgsql
    AS $$
DECLARE
    dto utils.quiz_create_dto;

BEGIN
    dto.question_id := dataparam ->> 'question_id';
    dto.user_answers:=dataparam->>'user_answers';


    return dto;
end;
$$;


ALTER FUNCTION mapper.to_quiz_history_dto(dataparam jsonb) OWNER TO postgres;

--
-- Name: to_variant_create(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_variant_create(dataparam jsonb) RETURNS utils.variant_create
    LANGUAGE plpgsql
    AS $$
declare
    dto utils.variant_create;
begin


    dto.question_id := dataparam ->> 'question_id';
    dto.variant_body := dataparam ->> 'variant_body';
    dto.is_correct := dataparam ->> 'is_correct';
    dto.created_by := dataparam ->> 'created_by';

    if dto.question_id is null then
        return null;
    end if;

    return dto;


end;
$$;


ALTER FUNCTION mapper.to_variant_create(dataparam jsonb) OWNER TO postgres;

--
-- Name: to_variant_update_dto(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_variant_update_dto(dataparam jsonb) RETURNS utils.variant_update_dto
    LANGUAGE plpgsql
    AS $$
declare
    dto utils.variant_update_dto;
begin

    dto.is_correct := dataparam ->> 'is_correct';
    dto.variant_body := dataparam ->> 'variant_body';
    dto.variant_id := dataparam ->> 'variant_id';

    return dto;


end
$$;


ALTER FUNCTION mapper.to_variant_update_dto(dataparam jsonb) OWNER TO postgres;

--
-- Name: to_variants(jsonb); Type: FUNCTION; Schema: mapper; Owner: postgres
--

CREATE FUNCTION mapper.to_variants(dataparam jsonb) RETURNS utils.variant_create[]
    LANGUAGE plpgsql
    AS $$
declare
    dto_arr      utils.variant_create[];
    variantJsonb jsonb;
    variants     jsonb;

begin

    call helper.check_dataparam(dataparam::text);
    variants := dataparam;

    for variantJsonb in select jsonb_array_elements(variants)
        loop
            dto_arr := array_append(dto_arr, mapper.to_variant_create(variantJsonb));
        end loop;

    dto_arr := array_remove(dto_arr, null);

    if array_length(dto_arr, 1) = 0 then
        return null;
    end if;

    return dto_arr;
end
$$;


ALTER FUNCTION mapper.to_variants(dataparam jsonb) OWNER TO postgres;

--
-- Name: auth_login(character varying, character varying); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.auth_login(uname character varying DEFAULT NULL::character varying, pswd character varying DEFAULT NULL::character varying) RETURNS text
    LANGUAGE plpgsql
    AS $$
declare
    t_user record;
begin

    select * into t_user from quizapp.auth_user t where t.username = lower(uname);

    if not FOUND then
        raise exception using message = 'Bad credentials',
            detail = concat_ws(' ', 'Username', uname, 'already taken');
    end if;

    if utils.match_password(pswd, t_user.password) is false then
        raise exception 'Bad credentials';
    end if;
    return json_build_object('id', t_user.id,
                             'username', t_user.username,
                             'language', t_user.language,
                             'role', t_user.role)::text;

end
$$;


ALTER FUNCTION quizapp.auth_login(uname character varying, pswd character varying) OWNER TO postgres;

--
-- Name: auth_register(text); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.auth_register(dataparam text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    newId    int4;
    dataJson json;
    t_user   record;
    dto      quizapp.user_register_dto;
begin
    if dataparam isnull or dataparam = '{}'::text then
        raise exception 'Data param can not be null';
    end if;

    dataJson := dataparam::json;
    dto.username := dataJson ->> 'username';
    dto.password := dataJson ->> 'password';
    dto.language := upper(dataJson ->> 'language');

    if dto.username is null or trim(dto.username) = '' then
        raise exception 'Username is invalid';
    end if;

    select *
    into t_user
    from quizapp.auth_user t
    where t.username = lower(dto.username);

    if FOUND then
        raise using message = 'User already exists';
    end if;

    if dto.password is null or trim(dto.password) = '' then
        raise exception 'Password is invalid';
    end if;

    if not exists(select * from quizapp.language l where l.code = dto.language) then
        dto.language := 'UZ';
    end if;

    dto.role := 'USER';

    insert into auth_user (username, password, role, language)
    values (dto.username,
            utils.encode_password(dto.password),
            dto.role,
            dto.language)
    returning id into newId;

    return newId;
end
$$;


ALTER FUNCTION quizapp.auth_register(dataparam text) OWNER TO postgres;

--
-- Name: get_quiz_question(integer, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.get_quiz_question(quizid integer, userid integer) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
    questionJson jsonb;
begin
    questionJson := jsonb_agg(jsonb_build_object(
                            'questionInfo', quizapp.questionInfo(qq.question_id)
                        ))
                    from quizapp.quiz_question qq
                             inner join quizapp.quiz q on q.id = qq.quiz_id
                    where qq.quiz_id = quizid
                      and q.user_id = userid
                      and qq.correct is null
                    order by random()
                    limit 1;
    return questionJson;
end
$$;


ALTER FUNCTION quizapp.get_quiz_question(quizid integer, userid integer) OWNER TO postgres;

--
-- Name: hasanyrole(character varying, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.hasanyrole(roles character varying, userid integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
begin
    return exists(select *
                  from quizapp.auth_user u
                  where u.id = userid
                    and u.role = any (regexp_split_to_array(roles, '#')));
end
$$;


ALTER FUNCTION quizapp.hasanyrole(roles character varying, userid integer) OWNER TO postgres;

--
-- Name: hasrole(character varying, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.hasrole(role character varying, userid integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
declare
    r_user record;
begin
    select * into r_user from quizapp.auth_user u where u.id = userid;
    return FOUND and r_user.role = role;
end
$$;


ALTER FUNCTION quizapp.hasrole(role character varying, userid integer) OWNER TO postgres;

--
-- Name: isactive(integer); Type: PROCEDURE; Schema: quizapp; Owner: postgres
--

CREATE PROCEDURE quizapp.isactive(IN userid integer)
    LANGUAGE plpgsql
    AS $$
declare
    t_user record;
BEGIN

    select * into t_user from quizapp.auth_user t where t.id = userid;
    if not FOUND then
        raise exception 'User not found by id : "%"',userid;
    end if;
END
$$;


ALTER PROCEDURE quizapp.isactive(IN userid integer) OWNER TO postgres;

--
-- Name: isblank(character varying, character varying); Type: PROCEDURE; Schema: quizapp; Owner: postgres
--

CREATE PROCEDURE quizapp.isblank(IN param character varying, IN message character varying DEFAULT NULL::character varying)
    LANGUAGE plpgsql
    AS $$
declare
begin

    if param is null or trim(param::varchar) = '' then
        raise '%', coalesce(message, concat('Invalid input ', param));
    end if;
end
$$;


ALTER PROCEDURE quizapp.isblank(IN param character varying, IN message character varying) OWNER TO postgres;

--
-- Name: level_create(text, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.level_create(dataparam text, userid integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
    dataJson json;
    dto      quizapp.level_create_dto;
begin

    call quizapp.isactive(userid);
    call quizapp.isBlank(dataparam);
        
    if not quizapp.hasAnyRole('ADMIN#TEACHER', userid) then
        raise 'Permission denied';
    end if;

    dataJson := dataparam::json;
    dto.code = dataJson ->> 'code';
    dto.subject = dataJson ->> 'subject';
    dto.translations = dataJson ->> 'translations';

    call quizapp.isBlank(dto.code);
    call quizapp.isBlank(dto.subject);
    call quizapp.isBlank(dto.translations::text);

    insert into quizapp.level values (dto.code,
                                      dto.subject,
                                      dto.translations);
    return dto.code;
end;
$$;


ALTER FUNCTION quizapp.level_create(dataparam text, userid integer) OWNER TO postgres;

--
-- Name: question_create(character varying, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.question_create(dataparam character varying, userid integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    dataJson  json;
    dto       quizapp.question_create_dto;
    r_subject record;
    newID     int;
begin
    call quizapp.isblank(dataparam,'Data param can not be null');
    call quizapp.isactive(userid);

    if not quizapp.hasanyrole('ADMIN#TEACHER', userid) then
        raise 'Permission denied';
    end if;

    dataJson := dataparam::json;
    dto.title := dataJson ->> 'title';
    dto.subject := upper(dataJson ->> 'subject');
    dto.translations := upper(dataJson ->> 'translations');
    dto.choices := dataJson ->> 'choices';
    ------------- check --------------
    select * into r_subject from quizapp.subject s where s.code = dto.subject;

    if not FOUND then
        raise 'Subject not found by code "%"',dto.subject;
    end if;

    call quizapp.isblank(dto.title);
    call quizapp.isblank(dto.subject);
    call quizapp.isblank(dto.choices::text);


    insert into quizapp.question (subject, title, level, translations)
    values (dto.subject, dto.title, dto.level, dto.translations)
    returning id into newID;


    insert into quizapp.answer (question_id, choices)
    values (newID, dto.choices);

    return newID;
end;
$$;


ALTER FUNCTION quizapp.question_create(dataparam character varying, userid integer) OWNER TO postgres;

--
-- Name: questioninfo(integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.questioninfo(questionid integer) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
    r_question record;
begin
    select q.title, a.choices
    into r_question
    from quizapp.question q
             inner join quizapp.answer a on q.id = a.question_id
    where q.id = questionid
      and a.question_id = questionid;
    if FOUND then
        return row_to_json(X)::jsonb
            FROM (SELECT r_question.title, r_question.choices) AS X;
    else
        return null;
    end if;
end
$$;


ALTER FUNCTION quizapp.questioninfo(questionid integer) OWNER TO postgres;

--
-- Name: quiz_generate(text, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.quiz_generate(dataparam text DEFAULT NULL::text, userid integer DEFAULT NULL::integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
    dataJson   json;
    dto        quizapp.quiz_generate_dto;
    quizid     integer;
    questionid integer;
BEGIN
    call quizapp.isactive(userid);
    call quizapp.isblank(dataparam);
    dataJson := dataparam::json;

    dto.language := dataJson ->> 'language';
    dto.subject := dataJson ->> 'subject';
    dto.level := dataJson ->> 'level';
    dto.questioncount := dataJson ->> 'questioncount';

    call quizapp.isblank(dto.language);
    call quizapp.isblank(dto.subject);
    call quizapp.isblank(dto.level);
    call quizapp.isblank(dto.questioncount::varchar);

    if (select count(*) from quizapp.question where subject = dto.subject and level = dto.level) <
       dto.questioncount then
        raise 'number of questions is not enough';
    end if;

    insert into quizapp.quiz(user_id, subject, level, language, total_question_count)
    values (userid, dto.subject, dto.level, dto.language, dto.questioncount)
    returning id into quizid;

    for questionid in (select id
                       from quizapp.question
                       where subject = dto.subject
                         and level = dto.level
                       order by random()
                       limit dto.questioncount)
        loop
            insert into quizapp.quiz_question(quiz_id, question_id)
            values (quizid, questionid);
        end loop;

    return quizid;
END
$$;


ALTER FUNCTION quizapp.quiz_generate(dataparam text, userid integer) OWNER TO postgres;

--
-- Name: subject_create(text, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.subject_create(dataparam text, userid integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
    dataJson json;
    dto      quizapp.subject_create_dto;
begin

    call quizapp.isblank(dataparam, 'Dataparam can not ber empty or null');
    call quizapp.isactive(userid);

    if not quizapp.hasAnyRole('ADMIN#TEACHER', userid) then
        raise 'Permission denied';
    end if;


    dataJson := dataparam::json;
    dto.code := upper(dataJson ->> 'code');
    dto.name := dataJson ->> 'name';
    dto.translations := dataJson ->> 'translations';

    call quizapp.isblank(dto.code);
    call quizapp.isblank(dto.name);
    call quizapp.isblank(dto.translations::text);


    if dto.translations = '{}'::jsonb then
        raise 'Subject must have at least one translation';
    end if;


    if exists(select * from quizapp.subject s where s.code = dto.code) then
        raise 'Subject with code "%" already created',dto.code;
    end if;

    insert into quizapp.subject (code, name, translations)
    values (dto.code, dto.name, dto.translations);
    return dto.code;
end
$$;


ALTER FUNCTION quizapp.subject_create(dataparam text, userid integer) OWNER TO postgres;

--
-- Name: teacher_create(text, integer); Type: FUNCTION; Schema: quizapp; Owner: postgres
--

CREATE FUNCTION quizapp.teacher_create(dataparam text, userid integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
declare
    dataJson json;
    dto      quizapp.user_register_dto;
    r_user   record;
    newId    int4;
begin

    call quizapp.isactive(userid);
    
    if dataparam isnull or dataparam = '{}'::text then
        raise exception 'Data param can not be null';
    end if;

    if not hasRole('ADMIN', userid) then
        raise 'Permission denied';
    end if;

    dataJson := dataparam::json;
    dto.username := dataJson ->> 'username';
    dto.password := dataJson ->> 'password';
    dto.language := upper(dataJson ->> 'language');
    dto.role := 'TEACHER';

    if dto.username is null or trim(dto.username) = '' then
        raise exception 'Username is invalid';
    end if;

    select *
    into r_user
    from quizapp.auth_user t
    where t.username = lower(dto.username);

    if FOUND then
        raise 'User already exists with username "%"',dto.username;
    end if;

    if dto.password is null or trim(dto.password) = '' then
        raise exception 'Password is invalid';
    end if;

    if not exists(select * from quizapp.language l where l.code = dto.language) then
        dto.language := 'UZ';
    end if;

    insert into auth_user (username, password, role, language)
    values (dto.username,
            utils.encode_password(dto.password),
            dto.role,
            dto.language)
    returning id into newId;

    return newId;


end
$$;


ALTER FUNCTION quizapp.teacher_create(dataparam text, userid integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: category_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.category_audits_table (
    id bigint NOT NULL,
    category_id smallint NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp without time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT category_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.category_audits_table OWNER TO postgres;

--
-- Name: category_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.category_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.category_audits_table_id_seq OWNER TO postgres;

--
-- Name: category_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.category_audits_table_id_seq OWNED BY logs.category_audits_table.id;


--
-- Name: language_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.language_audits_table (
    id bigint NOT NULL,
    language_id smallint NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp without time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT language_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.language_audits_table OWNER TO postgres;

--
-- Name: language_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.language_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.language_audits_table_id_seq OWNER TO postgres;

--
-- Name: language_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.language_audits_table_id_seq OWNED BY logs.language_audits_table.id;


--
-- Name: level_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.level_audits_table (
    id bigint NOT NULL,
    level_id integer NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp without time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT level_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.level_audits_table OWNER TO postgres;

--
-- Name: level_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.level_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.level_audits_table_id_seq OWNER TO postgres;

--
-- Name: level_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.level_audits_table_id_seq OWNED BY logs.level_audits_table.id;


--
-- Name: question_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.question_audits_table (
    id bigint NOT NULL,
    question_id bigint NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp without time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT question_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.question_audits_table OWNER TO postgres;

--
-- Name: question_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.question_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.question_audits_table_id_seq OWNER TO postgres;

--
-- Name: question_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.question_audits_table_id_seq OWNED BY logs.question_audits_table.id;


--
-- Name: quiz_history_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.quiz_history_audits_table (
    id bigint NOT NULL,
    quiz_history_id bigint NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp without time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT quiz_history_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.quiz_history_audits_table OWNER TO postgres;

--
-- Name: quiz_history_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.quiz_history_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.quiz_history_audits_table_id_seq OWNER TO postgres;

--
-- Name: quiz_history_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.quiz_history_audits_table_id_seq OWNED BY logs.quiz_history_audits_table.id;


--
-- Name: users_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.users_audits_table (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp with time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT users_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.users_audits_table OWNER TO postgres;

--
-- Name: users_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.users_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.users_audits_table_id_seq OWNER TO postgres;

--
-- Name: users_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.users_audits_table_id_seq OWNED BY logs.users_audits_table.id;


--
-- Name: variant_audits_table; Type: TABLE; Schema: logs; Owner: postgres
--

CREATE TABLE logs.variant_audits_table (
    id bigint NOT NULL,
    variant_id bigint NOT NULL,
    old_row_data text,
    new_row_data text,
    dml_type character varying(10) NOT NULL,
    dml_time_stamp timestamp without time zone NOT NULL,
    dml_created_by bigint,
    row_name character varying,
    CONSTRAINT variant_audits_table_dml_type_check CHECK (((dml_type)::text = ANY ((ARRAY['INSERT'::character varying, 'DELETE'::character varying, 'UPDATE'::character varying])::text[])))
);


ALTER TABLE logs.variant_audits_table OWNER TO postgres;

--
-- Name: variant_audits_table_id_seq; Type: SEQUENCE; Schema: logs; Owner: postgres
--

CREATE SEQUENCE logs.variant_audits_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE logs.variant_audits_table_id_seq OWNER TO postgres;

--
-- Name: variant_audits_table_id_seq; Type: SEQUENCE OWNED BY; Schema: logs; Owner: postgres
--

ALTER SEQUENCE logs.variant_audits_table_id_seq OWNED BY logs.variant_audits_table.id;


--
-- Name: category_id_seq; Type: SEQUENCE; Schema: utils; Owner: postgres
--

CREATE SEQUENCE utils.category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE utils.category_id_seq OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    id smallint DEFAULT nextval('utils.category_id_seq'::regclass) NOT NULL,
    category_name utils.no_null_length_zero_varchar,
    language_id smallint DEFAULT 1 NOT NULL,
    is_deleted smallint DEFAULT 0 NOT NULL,
    created_at timestamp(0) with time zone DEFAULT '2023-01-07 22:15:57.024598+05'::timestamp with time zone NOT NULL,
    created_by bigint NOT NULL,
    updated_at timestamp(0) with time zone,
    updated_by bigint
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: language_id_seq; Type: SEQUENCE; Schema: utils; Owner: postgres
--

CREATE SEQUENCE utils.language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE utils.language_id_seq OWNER TO postgres;

--
-- Name: language; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.language (
    id smallint DEFAULT nextval('utils.language_id_seq'::regclass) NOT NULL,
    name utils.no_null_length_zero_varchar,
    code utils.no_null_length_zero_varchar,
    is_deleted smallint DEFAULT 0 NOT NULL,
    updated_by bigint,
    updated_at timestamp with time zone
);


ALTER TABLE public.language OWNER TO postgres;

--
-- Name: level_id_seq; Type: SEQUENCE; Schema: utils; Owner: postgres
--

CREATE SEQUENCE utils.level_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE utils.level_id_seq OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.level (
    id integer DEFAULT nextval('utils.level_id_seq'::regclass) NOT NULL,
    level_name utils.no_null_length_zero_varchar,
    category_id bigint NOT NULL,
    power integer DEFAULT 0,
    created_at timestamp(0) with time zone DEFAULT '2023-01-07 22:15:57.056467+05'::timestamp with time zone NOT NULL,
    created_by bigint NOT NULL,
    updated_at timestamp(0) with time zone,
    updated_by bigint,
    is_deleted smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.level OWNER TO postgres;

--
-- Name: question_id_seq; Type: SEQUENCE; Schema: utils; Owner: postgres
--

CREATE SEQUENCE utils.question_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE utils.question_id_seq OWNER TO postgres;

--
-- Name: question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.question (
    id bigint DEFAULT nextval('utils.question_id_seq'::regclass) NOT NULL,
    category_id bigint NOT NULL,
    question_body text NOT NULL,
    level_id smallint NOT NULL,
    created_at timestamp(0) with time zone DEFAULT '2023-01-07 22:15:57.087037+05'::timestamp with time zone NOT NULL,
    created_by bigint NOT NULL,
    updated_at timestamp(0) with time zone,
    updated_by bigint,
    correct_answers smallint DEFAULT 0 NOT NULL,
    is_deleted smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.question OWNER TO postgres;

--
-- Name: quiz_history_id_seq; Type: SEQUENCE; Schema: utils; Owner: postgres
--

CREATE SEQUENCE utils.quiz_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE utils.quiz_history_id_seq OWNER TO postgres;

--
-- Name: quiz_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_history (
    id bigint DEFAULT nextval('utils.quiz_history_id_seq'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    correct_answers smallint,
    created_at timestamp(0) with time zone DEFAULT '2023-01-07 22:15:57.146394+05'::timestamp with time zone NOT NULL,
    updated_at timestamp(0) with time zone,
    updated_by bigint,
    is_deleted smallint DEFAULT 0,
    question_count smallint NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone
);


ALTER TABLE public.quiz_history OWNER TO postgres;

--
-- Name: quiz_question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_question (
    quiz_id bigint NOT NULL,
    question_id bigint NOT NULL,
    correct boolean,
    user_choices bigint[]
);


ALTER TABLE public.quiz_question OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint DEFAULT nextval('utils.category_id_seq'::regclass) NOT NULL,
    username utils.no_null_length_zero_varchar,
    password utils.no_null_length_zero_varchar,
    fullname utils.no_null_length_zero_varchar,
    email utils.no_null_length_zero_varchar,
    role utils.user_role DEFAULT 'USER'::utils.user_role NOT NULL,
    is_deleted smallint DEFAULT 0 NOT NULL,
    created_at timestamp(0) with time zone DEFAULT '2023-01-07 22:15:56.950134+05'::timestamp with time zone NOT NULL,
    updated_at timestamp(0) with time zone,
    updated_by bigint,
    language_id smallint NOT NULL,
    CONSTRAINT users_email_check CHECK (((email)::text ~ '^(?=.{1,64}@)[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*(\.[A-Za-z]{2,})$'::text))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: quiz_variants_id_seq; Type: SEQUENCE; Schema: utils; Owner: postgres
--

CREATE SEQUENCE utils.quiz_variants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE utils.quiz_variants_id_seq OWNER TO postgres;

--
-- Name: variant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.variant (
    id bigint DEFAULT nextval('utils.quiz_variants_id_seq'::regclass) NOT NULL,
    question_id bigint NOT NULL,
    body utils.no_null_length_zero_text,
    is_correct boolean DEFAULT false NOT NULL,
    created_at timestamp(0) with time zone DEFAULT now() NOT NULL,
    created_by bigint,
    updated_at timestamp(0) with time zone,
    updated_by bigint,
    is_deleted smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.variant OWNER TO postgres;

--
-- Name: answer; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.answer (
    id integer NOT NULL,
    question_id integer,
    choices jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT answer_choices_count_check CHECK ((jsonb_array_length(choices) > 0))
);


ALTER TABLE quizapp.answer OWNER TO postgres;

--
-- Name: answer_id_seq; Type: SEQUENCE; Schema: quizapp; Owner: postgres
--

CREATE SEQUENCE quizapp.answer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE quizapp.answer_id_seq OWNER TO postgres;

--
-- Name: answer_id_seq; Type: SEQUENCE OWNED BY; Schema: quizapp; Owner: postgres
--

ALTER SEQUENCE quizapp.answer_id_seq OWNED BY quizapp.answer.id;


--
-- Name: auth_role; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.auth_role (
    code character varying NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE quizapp.auth_role OWNER TO postgres;

--
-- Name: auth_user; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.auth_user (
    id integer NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    role character varying,
    language character varying
);


ALTER TABLE quizapp.auth_user OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: quizapp; Owner: postgres
--

CREATE SEQUENCE quizapp.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE quizapp.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: quizapp; Owner: postgres
--

ALTER SEQUENCE quizapp.auth_user_id_seq OWNED BY quizapp.auth_user.id;


--
-- Name: language; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.language (
    code character varying NOT NULL,
    name character varying
);


ALTER TABLE quizapp.language OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.level (
    code character varying NOT NULL,
    subject character varying,
    translations jsonb
);


ALTER TABLE quizapp.level OWNER TO postgres;

--
-- Name: question; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.question (
    id integer NOT NULL,
    subject character varying,
    title character varying NOT NULL,
    level character varying,
    translations jsonb
);


ALTER TABLE quizapp.question OWNER TO postgres;

--
-- Name: question_id_seq; Type: SEQUENCE; Schema: quizapp; Owner: postgres
--

CREATE SEQUENCE quizapp.question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE quizapp.question_id_seq OWNER TO postgres;

--
-- Name: question_id_seq; Type: SEQUENCE OWNED BY; Schema: quizapp; Owner: postgres
--

ALTER SEQUENCE quizapp.question_id_seq OWNED BY quizapp.question.id;


--
-- Name: quiz; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.quiz (
    id integer NOT NULL,
    user_id integer,
    subject character varying,
    level character varying,
    language character varying,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    finished_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    total_question_count smallint,
    wrong_question_count smallint,
    right_question_count smallint
);


ALTER TABLE quizapp.quiz OWNER TO postgres;

--
-- Name: quiz_id_seq; Type: SEQUENCE; Schema: quizapp; Owner: postgres
--

CREATE SEQUENCE quizapp.quiz_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE quizapp.quiz_id_seq OWNER TO postgres;

--
-- Name: quiz_id_seq; Type: SEQUENCE OWNED BY; Schema: quizapp; Owner: postgres
--

ALTER SEQUENCE quizapp.quiz_id_seq OWNED BY quizapp.quiz.id;


--
-- Name: quiz_question; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.quiz_question (
    id integer NOT NULL,
    quiz_id integer,
    question_id integer,
    correct boolean
);


ALTER TABLE quizapp.quiz_question OWNER TO postgres;

--
-- Name: quiz_question_id_seq; Type: SEQUENCE; Schema: quizapp; Owner: postgres
--

CREATE SEQUENCE quizapp.quiz_question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE quizapp.quiz_question_id_seq OWNER TO postgres;

--
-- Name: quiz_question_id_seq; Type: SEQUENCE OWNED BY; Schema: quizapp; Owner: postgres
--

ALTER SEQUENCE quizapp.quiz_question_id_seq OWNED BY quizapp.quiz_question.id;


--
-- Name: settings; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.settings (
);


ALTER TABLE quizapp.settings OWNER TO postgres;

--
-- Name: subject; Type: TABLE; Schema: quizapp; Owner: postgres
--

CREATE TABLE quizapp.subject (
    code character varying NOT NULL,
    name character varying NOT NULL,
    translations jsonb
);


ALTER TABLE quizapp.subject OWNER TO postgres;

--
-- Name: category_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.category_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.category_audits_table_id_seq'::regclass);


--
-- Name: language_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.language_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.language_audits_table_id_seq'::regclass);


--
-- Name: level_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.level_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.level_audits_table_id_seq'::regclass);


--
-- Name: question_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.question_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.question_audits_table_id_seq'::regclass);


--
-- Name: quiz_history_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.quiz_history_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.quiz_history_audits_table_id_seq'::regclass);


--
-- Name: users_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.users_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.users_audits_table_id_seq'::regclass);


--
-- Name: variant_audits_table id; Type: DEFAULT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.variant_audits_table ALTER COLUMN id SET DEFAULT nextval('logs.variant_audits_table_id_seq'::regclass);


--
-- Name: answer id; Type: DEFAULT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.answer ALTER COLUMN id SET DEFAULT nextval('quizapp.answer_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.auth_user ALTER COLUMN id SET DEFAULT nextval('quizapp.auth_user_id_seq'::regclass);


--
-- Name: question id; Type: DEFAULT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.question ALTER COLUMN id SET DEFAULT nextval('quizapp.question_id_seq'::regclass);


--
-- Name: quiz id; Type: DEFAULT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz ALTER COLUMN id SET DEFAULT nextval('quizapp.quiz_id_seq'::regclass);


--
-- Name: quiz_question id; Type: DEFAULT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz_question ALTER COLUMN id SET DEFAULT nextval('quizapp.quiz_question_id_seq'::regclass);


--
-- Data for Name: category_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.category_audits_table (id, category_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.category_audits_table (id, category_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3869.dat';

--
-- Data for Name: language_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.language_audits_table (id, language_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.language_audits_table (id, language_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3873.dat';

--
-- Data for Name: level_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.level_audits_table (id, level_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.level_audits_table (id, level_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3871.dat';

--
-- Data for Name: question_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.question_audits_table (id, question_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.question_audits_table (id, question_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3875.dat';

--
-- Data for Name: quiz_history_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.quiz_history_audits_table (id, quiz_history_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.quiz_history_audits_table (id, quiz_history_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3879.dat';

--
-- Data for Name: users_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.users_audits_table (id, user_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.users_audits_table (id, user_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3867.dat';

--
-- Data for Name: variant_audits_table; Type: TABLE DATA; Schema: logs; Owner: postgres
--

COPY logs.variant_audits_table (id, variant_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM stdin;
\.
COPY logs.variant_audits_table (id, variant_id, old_row_data, new_row_data, dml_type, dml_time_stamp, dml_created_by, row_name) FROM '$$PATH$$/3877.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (id, category_name, language_id, is_deleted, created_at, created_by, updated_at, updated_by) FROM stdin;
\.
COPY public.category (id, category_name, language_id, is_deleted, created_at, created_by, updated_at, updated_by) FROM '$$PATH$$/3854.dat';

--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.language (id, name, code, is_deleted, updated_by, updated_at) FROM stdin;
\.
COPY public.language (id, name, code, is_deleted, updated_by, updated_at) FROM '$$PATH$$/3859.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.level (id, level_name, category_id, power, created_at, created_by, updated_at, updated_by, is_deleted) FROM stdin;
\.
COPY public.level (id, level_name, category_id, power, created_at, created_by, updated_at, updated_by, is_deleted) FROM '$$PATH$$/3855.dat';

--
-- Data for Name: question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.question (id, category_id, question_body, level_id, created_at, created_by, updated_at, updated_by, correct_answers, is_deleted) FROM stdin;
\.
COPY public.question (id, category_id, question_body, level_id, created_at, created_by, updated_at, updated_by, correct_answers, is_deleted) FROM '$$PATH$$/3856.dat';

--
-- Data for Name: quiz_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_history (id, user_id, correct_answers, created_at, updated_at, updated_by, is_deleted, question_count, started_at, finished_at) FROM stdin;
\.
COPY public.quiz_history (id, user_id, correct_answers, created_at, updated_at, updated_by, is_deleted, question_count, started_at, finished_at) FROM '$$PATH$$/3858.dat';

--
-- Data for Name: quiz_question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_question (quiz_id, question_id, correct, user_choices) FROM stdin;
\.
COPY public.quiz_question (quiz_id, question_id, correct, user_choices) FROM '$$PATH$$/3895.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, fullname, email, role, is_deleted, created_at, updated_at, updated_by, language_id) FROM stdin;
\.
COPY public.users (id, username, password, fullname, email, role, is_deleted, created_at, updated_at, updated_by, language_id) FROM '$$PATH$$/3853.dat';

--
-- Data for Name: variant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.variant (id, question_id, body, is_correct, created_at, created_by, updated_at, updated_by, is_deleted) FROM stdin;
\.
COPY public.variant (id, question_id, body, is_correct, created_at, created_by, updated_at, updated_by, is_deleted) FROM '$$PATH$$/3857.dat';

--
-- Data for Name: answer; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.answer (id, question_id, choices) FROM stdin;
\.
COPY quizapp.answer (id, question_id, choices) FROM '$$PATH$$/3880.dat';

--
-- Data for Name: auth_role; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.auth_role (code, name) FROM stdin;
\.
COPY quizapp.auth_role (code, name) FROM '$$PATH$$/3882.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.auth_user (id, username, password, role, language) FROM stdin;
\.
COPY quizapp.auth_user (id, username, password, role, language) FROM '$$PATH$$/3883.dat';

--
-- Data for Name: language; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.language (code, name) FROM stdin;
\.
COPY quizapp.language (code, name) FROM '$$PATH$$/3885.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.level (code, subject, translations) FROM stdin;
\.
COPY quizapp.level (code, subject, translations) FROM '$$PATH$$/3886.dat';

--
-- Data for Name: question; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.question (id, subject, title, level, translations) FROM stdin;
\.
COPY quizapp.question (id, subject, title, level, translations) FROM '$$PATH$$/3887.dat';

--
-- Data for Name: quiz; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.quiz (id, user_id, subject, level, language, started_at, finished_at, total_question_count, wrong_question_count, right_question_count) FROM stdin;
\.
COPY quizapp.quiz (id, user_id, subject, level, language, started_at, finished_at, total_question_count, wrong_question_count, right_question_count) FROM '$$PATH$$/3889.dat';

--
-- Data for Name: quiz_question; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.quiz_question (id, quiz_id, question_id, correct) FROM stdin;
\.
COPY quizapp.quiz_question (id, quiz_id, question_id, correct) FROM '$$PATH$$/3891.dat';

--
-- Data for Name: settings; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.settings  FROM stdin;
\.
COPY quizapp.settings  FROM '$$PATH$$/3893.dat';

--
-- Data for Name: subject; Type: TABLE DATA; Schema: quizapp; Owner: postgres
--

COPY quizapp.subject (code, name, translations) FROM stdin;
\.
COPY quizapp.subject (code, name, translations) FROM '$$PATH$$/3894.dat';

--
-- Name: category_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.category_audits_table_id_seq', 1, false);


--
-- Name: language_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.language_audits_table_id_seq', 1, false);


--
-- Name: level_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.level_audits_table_id_seq', 1, false);


--
-- Name: question_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.question_audits_table_id_seq', 30, true);


--
-- Name: quiz_history_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.quiz_history_audits_table_id_seq', 4, true);


--
-- Name: users_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.users_audits_table_id_seq', 20, true);


--
-- Name: variant_audits_table_id_seq; Type: SEQUENCE SET; Schema: logs; Owner: postgres
--

SELECT pg_catalog.setval('logs.variant_audits_table_id_seq', 34, true);


--
-- Name: answer_id_seq; Type: SEQUENCE SET; Schema: quizapp; Owner: postgres
--

SELECT pg_catalog.setval('quizapp.answer_id_seq', 1, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: quizapp; Owner: postgres
--

SELECT pg_catalog.setval('quizapp.auth_user_id_seq', 7, true);


--
-- Name: question_id_seq; Type: SEQUENCE SET; Schema: quizapp; Owner: postgres
--

SELECT pg_catalog.setval('quizapp.question_id_seq', 1, true);


--
-- Name: quiz_id_seq; Type: SEQUENCE SET; Schema: quizapp; Owner: postgres
--

SELECT pg_catalog.setval('quizapp.quiz_id_seq', 1, true);


--
-- Name: quiz_question_id_seq; Type: SEQUENCE SET; Schema: quizapp; Owner: postgres
--

SELECT pg_catalog.setval('quizapp.quiz_question_id_seq', 1, true);


--
-- Name: category_id_seq; Type: SEQUENCE SET; Schema: utils; Owner: postgres
--

SELECT pg_catalog.setval('utils.category_id_seq', 27, true);


--
-- Name: language_id_seq; Type: SEQUENCE SET; Schema: utils; Owner: postgres
--

SELECT pg_catalog.setval('utils.language_id_seq', 5, true);


--
-- Name: level_id_seq; Type: SEQUENCE SET; Schema: utils; Owner: postgres
--

SELECT pg_catalog.setval('utils.level_id_seq', 30, true);


--
-- Name: question_id_seq; Type: SEQUENCE SET; Schema: utils; Owner: postgres
--

SELECT pg_catalog.setval('utils.question_id_seq', 69, true);


--
-- Name: quiz_history_id_seq; Type: SEQUENCE SET; Schema: utils; Owner: postgres
--

SELECT pg_catalog.setval('utils.quiz_history_id_seq', 12, true);


--
-- Name: quiz_variants_id_seq; Type: SEQUENCE SET; Schema: utils; Owner: postgres
--

SELECT pg_catalog.setval('utils.quiz_variants_id_seq', 49, true);


--
-- Name: category_audits_table category_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.category_audits_table
    ADD CONSTRAINT category_audits_table_pkey PRIMARY KEY (category_id, dml_type, dml_time_stamp);


--
-- Name: language_audits_table language_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.language_audits_table
    ADD CONSTRAINT language_audits_table_pkey PRIMARY KEY (language_id, dml_type, dml_time_stamp);


--
-- Name: level_audits_table level_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.level_audits_table
    ADD CONSTRAINT level_audits_table_pkey PRIMARY KEY (level_id, dml_type, dml_time_stamp);


--
-- Name: question_audits_table question_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.question_audits_table
    ADD CONSTRAINT question_audits_table_pkey PRIMARY KEY (question_id, dml_type, dml_time_stamp);


--
-- Name: quiz_history_audits_table quiz_history_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.quiz_history_audits_table
    ADD CONSTRAINT quiz_history_audits_table_pkey PRIMARY KEY (quiz_history_id, dml_type, dml_time_stamp);


--
-- Name: users_audits_table users_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.users_audits_table
    ADD CONSTRAINT users_audits_table_pkey PRIMARY KEY (user_id, dml_type, dml_time_stamp);


--
-- Name: variant_audits_table variant_audits_table_pkey; Type: CONSTRAINT; Schema: logs; Owner: postgres
--

ALTER TABLE ONLY logs.variant_audits_table
    ADD CONSTRAINT variant_audits_table_pkey PRIMARY KEY (variant_id, dml_type, dml_time_stamp);


--
-- Name: category category_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_category_name_key UNIQUE (category_name);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: language language_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_code_key UNIQUE (code);


--
-- Name: language language_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_name_key UNIQUE (name);


--
-- Name: language language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_pkey PRIMARY KEY (id);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id);


--
-- Name: question question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_pkey PRIMARY KEY (id);


--
-- Name: quiz_history quiz_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_history
    ADD CONSTRAINT quiz_history_pkey PRIMARY KEY (id);


--
-- Name: level uk_level_name_category_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.level
    ADD CONSTRAINT uk_level_name_category_id UNIQUE (level_name, category_id);


--
-- Name: quiz_question uk_quizid_question_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_question
    ADD CONSTRAINT uk_quizid_question_id UNIQUE (quiz_id, question_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: variant variant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variant
    ADD CONSTRAINT variant_pkey PRIMARY KEY (id);


--
-- Name: answer answer_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.answer
    ADD CONSTRAINT answer_pkey PRIMARY KEY (id);


--
-- Name: auth_role auth_role_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.auth_role
    ADD CONSTRAINT auth_role_pkey PRIMARY KEY (code);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: language language_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.language
    ADD CONSTRAINT language_pkey PRIMARY KEY (code);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.level
    ADD CONSTRAINT level_pkey PRIMARY KEY (code);


--
-- Name: question question_id_pk; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.question
    ADD CONSTRAINT question_id_pk PRIMARY KEY (id);


--
-- Name: quiz quiz_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz
    ADD CONSTRAINT quiz_pkey PRIMARY KEY (id);


--
-- Name: quiz_question quiz_question_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz_question
    ADD CONSTRAINT quiz_question_pkey PRIMARY KEY (id);


--
-- Name: subject subject_pkey; Type: CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.subject
    ADD CONSTRAINT subject_pkey PRIMARY KEY (code);


--
-- Name: category category_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER category_changes AFTER INSERT OR DELETE OR UPDATE ON public.category FOR EACH ROW EXECUTE FUNCTION logs.log_category_changes();


--
-- Name: language language_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER language_changes AFTER INSERT OR DELETE OR UPDATE ON public.language FOR EACH ROW EXECUTE FUNCTION logs.log_language_changes();


--
-- Name: level level_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER level_changes AFTER INSERT OR DELETE OR UPDATE ON public.level FOR EACH ROW EXECUTE FUNCTION logs.log_level_changes();


--
-- Name: question question_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER question_changes AFTER INSERT OR DELETE OR UPDATE ON public.question FOR EACH ROW EXECUTE FUNCTION logs.log_question_changes();


--
-- Name: quiz_history quiz_history_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER quiz_history_changes AFTER INSERT OR DELETE OR UPDATE ON public.quiz_history FOR EACH ROW EXECUTE FUNCTION logs.log_quiz_history_changes();


--
-- Name: users user_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER user_changes AFTER INSERT OR DELETE OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION logs.log_user_changes();


--
-- Name: variant variant_changes; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER variant_changes AFTER INSERT OR DELETE OR UPDATE ON public.variant FOR EACH ROW EXECUTE FUNCTION logs.log_variant_changes();


--
-- Name: category category_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: category category_language_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_language_id_foreign FOREIGN KEY (language_id) REFERENCES public.language(id);


--
-- Name: category category_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: language language_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.language
    ADD CONSTRAINT language_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: level level_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.level
    ADD CONSTRAINT level_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- Name: level level_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.level
    ADD CONSTRAINT level_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: level level_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.level
    ADD CONSTRAINT level_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: question question_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.category(id);


--
-- Name: question question_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: question question_level_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_level_id_foreign FOREIGN KEY (level_id) REFERENCES public.level(id);


--
-- Name: question question_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: quiz_history quiz_history_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_history
    ADD CONSTRAINT quiz_history_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: quiz_history quiz_history_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_history
    ADD CONSTRAINT quiz_history_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: quiz_question quiz_question_question_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_question
    ADD CONSTRAINT quiz_question_question_id_fk FOREIGN KEY (question_id) REFERENCES public.question(id);


--
-- Name: quiz_question quiz_question_quiz_history_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_question
    ADD CONSTRAINT quiz_question_quiz_history_id_fk FOREIGN KEY (quiz_id) REFERENCES public.quiz_history(id);


--
-- Name: users users_language_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_language_id_foreign FOREIGN KEY (language_id) REFERENCES public.language(id);


--
-- Name: variant variant_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variant
    ADD CONSTRAINT variant_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: variant variant_question_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variant
    ADD CONSTRAINT variant_question_id_foreign FOREIGN KEY (question_id) REFERENCES public.question(id);


--
-- Name: variant variant_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variant
    ADD CONSTRAINT variant_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: answer answer_question_question_id_id; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.answer
    ADD CONSTRAINT answer_question_question_id_id FOREIGN KEY (question_id) REFERENCES quizapp.question(id);


--
-- Name: auth_user auth_user_auth_role_role_code_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.auth_user
    ADD CONSTRAINT auth_user_auth_role_role_code_fk FOREIGN KEY (role) REFERENCES quizapp.auth_role(code);


--
-- Name: auth_user auth_user_language_language_code_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.auth_user
    ADD CONSTRAINT auth_user_language_language_code_fk FOREIGN KEY (language) REFERENCES quizapp.language(code);


--
-- Name: level level_subject_subject_code_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.level
    ADD CONSTRAINT level_subject_subject_code_fk FOREIGN KEY (subject) REFERENCES quizapp.subject(code);


--
-- Name: question question_level_level_code_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.question
    ADD CONSTRAINT question_level_level_code_fk FOREIGN KEY (level) REFERENCES quizapp.level(code);


--
-- Name: quiz quiz_language_language_code_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz
    ADD CONSTRAINT quiz_language_language_code_fk FOREIGN KEY (language) REFERENCES quizapp.language(code);


--
-- Name: quiz quiz_level_level_code_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz
    ADD CONSTRAINT quiz_level_level_code_fk FOREIGN KEY (level) REFERENCES quizapp.level(code);


--
-- Name: quiz_question quiz_question_question_id_id_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz_question
    ADD CONSTRAINT quiz_question_question_id_id_fk FOREIGN KEY (question_id) REFERENCES quizapp.question(id);


--
-- Name: quiz_question quiz_question_quiz_id_id_fk; Type: FK CONSTRAINT; Schema: quizapp; Owner: postgres
--

ALTER TABLE ONLY quizapp.quiz_question
    ADD CONSTRAINT quiz_question_quiz_id_id_fk FOREIGN KEY (quiz_id) REFERENCES quizapp.quiz(id);


--
-- PostgreSQL database dump complete
--

